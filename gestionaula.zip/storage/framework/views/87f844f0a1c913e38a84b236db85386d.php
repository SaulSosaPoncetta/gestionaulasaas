<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-person-check me-2"></i>Asistencia</h4>
        <p class="text-muted mb-0">Seleccioná la materia y el curso para continuar.</p>
        <?php if($horarioActivo): ?>
        <div class="mt-1">
            <span class="badge bg-success">
                <i class="bi bi-play-circle me-1"></i>Clase activa detectada:
                <?php echo e($horarioActivo->materia?->nombre); ?> — <?php echo e($horarioActivo->curso?->nombre_completo); ?>

            </span>
        </div>
        <?php endif; ?>
    </div>
    <div class="col-auto d-flex gap-2">
        <a href="<?php echo e(route('asistencia.alumno')); ?>" class="btn btn-outline-primary">
            <i class="bi bi-person-lines-fill me-1"></i>Buscar por alumno
        </a>
        <a href="<?php echo e(route('asistencia.historial')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-clock-history me-1"></i>Ver historial
        </a>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('asistencia.accion')); ?>" id="formAsistencia">

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        <span class="badge bg-primary me-1">1</span>Materia
                    </label>
                    <select name="materia_id" id="materia_id" class="form-select" required>
                        <option value="">Seleccioná una materia...</option>
                        <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($materia->id); ?>"
                                <?php echo e($materiaIdDefault == $materia->id ? 'selected' : ''); ?>>
                                <?php echo e($materia->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        <span class="badge bg-primary me-1">2</span>Curso
                    </label>
                    <select name="curso_id" id="curso_id" class="form-select" required>
                        <option value="">Seleccioná un curso...</option>
                        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($curso->id); ?>"
                                <?php echo e($cursoIdDefault == $curso->id ? 'selected' : ''); ?>>
                                <?php echo e($curso->nombre_completo); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-arrow-right-circle me-1"></i>Siguiente
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
const todosLosCursos = <?php echo json_encode($cursos->map(fn($c) => ['id' => $c->id, 'nombre' => $c->nombre_completo]), 512) ?>;
const cursoDefault   = <?php echo e($cursoIdDefault ?? 'null'); ?>;

// Al cambiar materia: recargar cursos via AJAX o por URL
document.getElementById('materia_id').addEventListener('change', function () {
    const materiaId = this.value;
    const cursoSel  = document.getElementById('curso_id');
    const urlActual = new URL(window.location.href);

    if (materiaId) {
        urlActual.searchParams.set('materia_id', materiaId);
    } else {
        urlActual.searchParams.delete('materia_id');
    }
    urlActual.searchParams.delete('curso_id');
    window.location.href = urlActual.toString();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/asistencia/index.blade.php ENDPATH**/ ?>