<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-clipboard2-check me-2"></i>Actividades</h4>
        <p class="text-muted">Gestión de actividades pedagógicas.</p>
    </div>
    <div class="col-auto">
        <a href="<?php echo e(route('actividades.seleccionar', $materiaActiva ? ['materia_id' => $materiaActiva] : [])); ?>"
           class="btn btn-primary">
            <i class="bi bi-plus-circle me-1"></i>Nueva actividad
        </a>
    </div>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('actividades.index')); ?>" class="row g-3">
            <div class="col-md-6">
                <label class="form-label fw-semibold">Filtrar por materia</label>
                <?php $haySeparador = false; ?>
                <select name="materia_id" id="materia_id" class="form-select">
                    <option value="">— Todas las materias —</option>
                    <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($m->id === $materiaActivaId): ?>
                            <option value="<?php echo e($m->id); ?>" <?php echo e($materiaActiva == $m->id ? 'selected' : ''); ?>>
                                ⚡ <?php echo e($m->nombre); ?> (activa ahora)
                            </option>
                        <?php elseif($materiasEnHorario->contains($m->id)): ?>
                            <option value="<?php echo e($m->id); ?>" <?php echo e($materiaActiva == $m->id ? 'selected' : ''); ?>>
                                📅 <?php echo e($m->nombre); ?>

                            </option>
                        <?php else: ?>
                            <?php if(!$haySeparador): ?> <?php $haySeparador = true ?> <option disabled>──────────────</option> <?php endif; ?>
                            <option value="<?php echo e($m->id); ?>" <?php echo e($materiaActiva == $m->id ? 'selected' : ''); ?>>
                                <?php echo e($m->nombre); ?>

                            </option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($materiaActivaId): ?>
                <div class="form-text">
                    <i class="bi bi-lightning-charge-fill text-success me-1"></i>Activa ahora &nbsp;
                    <span>📅 En tu horario</span>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i>Filtrar
                </button>
            </div>
            <?php if(request('materia_id')): ?>
            <div class="col-md-3 d-flex align-items-end">
                <a href="<?php echo e(route('actividades.index')); ?>" class="btn btn-outline-secondary w-100">
                    <i class="bi bi-x-circle me-1"></i>Limpiar
                </a>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<?php if($actividades->isEmpty()): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>No hay actividades registradas.
    </div>
<?php else: ?>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th class="ps-4 text-center">Unidad</th>
                    <th class="text-center">N° Act.</th>
                    <th>Materia</th>
                    <th>Tema</th>
                    <th>Subtema</th>
                    <th>Tipo</th>
                    <th class="text-center">Items</th>
                    <th class="text-center">Estado</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="ps-4 text-center">
                        <?php if($act->numerounidad): ?>
                            <span class="badge bg-secondary"><?php echo e($act->numerounidad); ?></span>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center fw-bold">
                        <?php echo e($act->numeroactividad ?? '—'); ?>

                    </td>
                    <td><?php echo e($act->materia?->nombre ?? '—'); ?></td>
                    <td class="fw-semibold"><?php echo e($act->tema); ?></td>
                    <td class="text-muted small"><?php echo e($act->subtema ?? '—'); ?></td>
                    <td><?php echo e($act->tipoactividad?->denominacion ?? '—'); ?></td>
                    <td class="text-center">
                        <span class="badge bg-info"><?php echo e($act->items->count()); ?></span>
                    </td>
                    <td class="text-center">
                        <span class="badge bg-<?php echo e($act->estado === 'activa' ? 'success' : 'secondary'); ?>">
                            <?php echo e(ucfirst($act->estado)); ?>

                        </span>
                    </td>
                    <td class="text-end pe-3">
                        <a href="<?php echo e(route('actividades.show', $act)); ?>"
                           class="btn btn-sm btn-outline-primary me-1">
                            <i class="bi bi-eye"></i>
                        </a>
                        <form method="POST" action="<?php echo e(route('actividades.destroy', $act)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger"
                                    onclick="return confirm('¿Eliminar esta actividad?')">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($actividades->links()); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.getElementById('materia_id').addEventListener('change', function () {
    this.closest('form').submit();
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/actividades/index.blade.php ENDPATH**/ ?>