<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-file-earmark-text me-2"></i>Declaraciones juradas</h4>
        <p class="text-muted">Historial de declaraciones juradas de horarios.</p>
    </div>
    <div class="col-auto">
        <?php if(auth()->user()->hasRole('docente')): ?>
        <a href="<?php echo e(route('declaracion.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle me-1"></i>Nueva declaración
        </a>
        <?php endif; ?>
    </div>
</div>

<?php if($declaraciones->isEmpty()): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>No hay declaraciones juradas todavía.
    </div>
<?php else: ?>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th class="ps-4">Ciclo</th>
                    <?php if(auth()->user()->hasRole('director')): ?>
                        <th>Docente</th>
                    <?php endif; ?>
                    <th>Estado</th>
                    <th>Presentación</th>
                    <th>Resolución</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $declaraciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="ps-4 fw-semibold"><?php echo e($dec->ciclo); ?></td>
                    <?php if(auth()->user()->hasRole('director')): ?>
                        <td><?php echo e($dec->docente->name); ?></td>
                    <?php endif; ?>
                    <td>
                        <span class="badge bg-<?php echo e($dec->estadobadge); ?>"><?php echo e(ucfirst($dec->estado)); ?></span>
                    </td>
                    <td><?php echo e($dec->fechapresentacion?->format('d/m/Y H:i') ?? '—'); ?></td>
                    <td><?php echo e($dec->fecharesolucion?->format('d/m/Y H:i') ?? '—'); ?></td>
                    <td>
                        <div class="d-flex gap-1">
                        <a href="<?php echo e(route('declaracion.show', $dec)); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-eye"></i>
                        </a>
                        <?php if($dec->estado === 'borrador'): ?>
                        <a href="<?php echo e(route('declaracion.edit', $dec)); ?>" class="btn btn-sm btn-secondary">
                            <i class="bi bi-pencil text-white"></i>
                        </a>
                        <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($declaraciones->links()); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/declaracion/index.blade.php ENDPATH**/ ?>