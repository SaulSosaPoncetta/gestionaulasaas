<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold">
            <i class="bi bi-journal-bookmark me-2"></i><?php echo e($planificacion->materia?->nombre); ?>

        </h4>
        <p class="text-muted mb-0">
            Ciclo lectivo: <strong><?php echo e($planificacion->ciclo); ?></strong>
            &mdash; Docente: <strong><?php echo e($planificacion->docente->name); ?></strong>
        </p>
        <?php if($planificacion->descripcion): ?>
            <p class="text-muted small mt-1"><?php echo e($planificacion->descripcion); ?></p>
        <?php endif; ?>
    </div>
    <div class="col-auto d-flex gap-2">
        <a href="<?php echo e(route('planificaciones.edit', $planificacion)); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-pencil me-1"></i>Editar
        </a>
        <a href="<?php echo e(route('planificaciones.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>


<?php $__empty_1 = true; $__currentLoopData = $planificacion->unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <span class="fw-semibold">
            <i class="bi bi-collection me-1"></i>
            Unidad <?php echo e($unidad->orden); ?>: <?php echo e($unidad->nombre); ?>

            <span class="badge bg-white text-primary ms-2"><?php echo e($unidad->numeroclases); ?> clases</span>
        </span>
        <form method="POST"
              action="<?php echo e(route('planificaciones.unidades.destroy', [$planificacion, $unidad])); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-sm btn-outline-light"
                    onclick="return confirm('¿Eliminar esta unidad?')">
                <i class="bi bi-trash"></i>
            </button>
        </form>
    </div>
    <div class="card-body">
        <div class="row g-4">

            
            <div class="col-md-6">
                <h6 class="fw-semibold text-muted mb-2">
                    <i class="bi bi-journal-richtext me-1"></i>Contenidos
                </h6>
                <?php if($unidad->contenidos->isNotEmpty()): ?>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $unidad->contenidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item px-0 py-1 border-0">
                            <i class="bi bi-dot text-primary"></i>
                            <?php echo e($cont->tema); ?>

                            <span class="text-muted small">(<?php echo e($cont->fecha->format('d/m/Y')); ?>)</span>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <span class="text-muted small">Sin contenidos asignados.</span>
                <?php endif; ?>
            </div>

            
            <div class="col-md-6">
                <h6 class="fw-semibold text-muted mb-2">
                    <i class="bi bi-bullseye me-1"></i>Objetivos de aprendizaje
                </h6>
                <?php if($unidad->objetivosaprendizaje->isNotEmpty()): ?>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $unidad->objetivosaprendizaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item px-0 py-1 border-0">
                            <i class="bi bi-dot text-success"></i><?php echo e($obj->objetivo); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <span class="text-muted small">Sin objetivos cargados.</span>
                <?php endif; ?>
            </div>

            
            <div class="col-md-6">
                <h6 class="fw-semibold text-muted mb-2">
                    <i class="bi bi-mortarboard me-1"></i>Objetivos de enseñanza
                </h6>
                <?php if($unidad->objetivosensenianza->isNotEmpty()): ?>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $unidad->objetivosensenianza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item px-0 py-1 border-0">
                            <i class="bi bi-dot text-warning"></i><?php echo e($obj->objetivo); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <span class="text-muted small">Sin objetivos cargados.</span>
                <?php endif; ?>
            </div>

            
            <div class="col-md-3">
                <h6 class="fw-semibold text-muted mb-2">
                    <i class="bi bi-activity me-1"></i>Actividades
                </h6>
                <?php if($unidad->actividades->isNotEmpty()): ?>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $unidad->actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item px-0 py-1 border-0">
                            <i class="bi bi-dot text-info"></i><?php echo e($act->actividad); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <span class="text-muted small">Sin actividades.</span>
                <?php endif; ?>
            </div>

            
            <div class="col-md-3">
                <h6 class="fw-semibold text-muted mb-2">
                    <i class="bi bi-tools me-1"></i>Recursos
                </h6>
                <?php if($unidad->recursos->isNotEmpty()): ?>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $unidad->recursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item px-0 py-1 border-0">
                            <i class="bi bi-dot text-secondary"></i><?php echo e($rec->recurso); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <span class="text-muted small">Sin recursos.</span>
                <?php endif; ?>
            </div>

            
            <?php if($unidad->archivos->isNotEmpty()): ?>
            <div class="col-12">
                <h6 class="fw-semibold text-muted mb-2">
                    <i class="bi bi-file-earmark-pdf me-1"></i>Material teórico
                </h6>
                <div class="d-flex flex-wrap gap-2">
                    <?php $__currentLoopData = $unidad->archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(asset('storage/' . $archivo->ruta)); ?>"
                       target="_blank" class="btn btn-sm btn-outline-danger">
                        <i class="bi bi-file-pdf me-1"></i><?php echo e($archivo->nombre); ?>

                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="alert alert-info">
    <i class="bi bi-info-circle me-2"></i>Esta planificación no tiene unidades. Agregá la primera abajo.
</div>
<?php endif; ?>


<div class="card border-0 shadow-sm border-start border-success border-4">
    <div class="card-header bg-white fw-semibold">
        <i class="bi bi-plus-circle me-1 text-success"></i>Agregar nueva unidad
    </div>
    <div class="card-body">
        <form method="POST"
              action="<?php echo e(route('planificaciones.unidades.store', $planificacion)); ?>"
              enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger mb-3">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="row g-3">
                
                <div class="col-md-8">
                    <label class="form-label fw-semibold">Nombre de la unidad <span class="text-danger">*</span></label>
                    <input type="text" name="nombre" class="form-control" required
                           placeholder="Ej: Unidad 1 - Introducción">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Número de clases <span class="text-danger">*</span></label>
                    <input type="number" name="numeroclases" class="form-control" min="1" value="1" required>
                </div>

                
                <div class="col-12">
                    <label class="form-label fw-semibold">
                        Contenidos <span class="text-muted fw-normal">(seleccioná uno o varios)</span>
                    </label>
                    <div class="border rounded p-2" style="max-height:150px; overflow-y:auto;">
                        <?php $__empty_1 = true; $__currentLoopData = $contenidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox"
                                   name="contenidos[]" value="<?php echo e($cont->id); ?>"
                                   id="cont<?php echo e($cont->id); ?>">
                            <label class="form-check-label small" for="cont<?php echo e($cont->id); ?>">
                                <strong><?php echo e($cont->tema); ?></strong>
                                <span class="text-muted">— <?php echo e($cont->materia?->nombre); ?> (<?php echo e($cont->fecha->format('d/m/Y')); ?>)</span>
                            </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="text-muted small">No hay contenidos cargados aún.</span>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        Objetivos de aprendizaje
                        <button type="button" class="btn btn-sm btn-outline-success ms-2"
                                onclick="agregarCampo('aprendizaje')">
                            <i class="bi bi-plus"></i>
                        </button>
                    </label>
                    <div id="campos-aprendizaje">
                        <input type="text" name="objetivosaprendizaje[]"
                               class="form-control form-control-sm mb-2"
                               placeholder="Objetivo de aprendizaje 1">
                    </div>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        Objetivos de enseñanza
                        <button type="button" class="btn btn-sm btn-outline-warning ms-2"
                                onclick="agregarCampo('ensenianza')">
                            <i class="bi bi-plus"></i>
                        </button>
                    </label>
                    <div id="campos-ensenianza">
                        <input type="text" name="objetivosensenianza[]"
                               class="form-control form-control-sm mb-2"
                               placeholder="Objetivo de enseñanza 1">
                    </div>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        Tipos de actividades
                        <button type="button" class="btn btn-sm btn-outline-info ms-2"
                                onclick="agregarCampo('actividades')">
                            <i class="bi bi-plus"></i>
                        </button>
                    </label>
                    <div id="campos-actividades">
                        <input type="text" name="actividades[]"
                               class="form-control form-control-sm mb-2"
                               placeholder="Tipo de actividad 1">
                    </div>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        Recursos
                        <button type="button" class="btn btn-sm btn-outline-secondary ms-2"
                                onclick="agregarCampo('recursos')">
                            <i class="bi bi-plus"></i>
                        </button>
                    </label>
                    <div id="campos-recursos">
                        <input type="text" name="recursos[]"
                               class="form-control form-control-sm mb-2"
                               placeholder="Recurso 1">
                    </div>
                </div>

                
                <div class="col-12">
                    <label class="form-label fw-semibold">
                        Material teórico en PDF
                        <span class="text-muted fw-normal">(máximo 3 archivos)</span>
                    </label>
                    <input type="file" name="archivos[]" class="form-control"
                           accept="application/pdf" multiple>
                    <div class="form-text">Podés seleccionar hasta 3 archivos PDF a la vez.</div>
                </div>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-success">
                    <i class="bi bi-check-circle me-1"></i>Agregar unidad
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function agregarCampo(tipo) {
    const contenedor = document.getElementById(`campos-${tipo}`);
    const cantidad   = contenedor.querySelectorAll('input').length + 1;
    const nombres    = {
        'aprendizaje': 'objetivosaprendizaje',
        'ensenianza':  'objetivosensenianza',
        'actividades': 'actividades',
        'recursos':    'recursos',
    };
    const placeholders = {
        'aprendizaje': 'Objetivo de aprendizaje',
        'ensenianza':  'Objetivo de enseñanza',
        'actividades': 'Tipo de actividad',
        'recursos':    'Recurso',
    };

    const input = document.createElement('input');
    input.type        = 'text';
    input.name        = `${nombres[tipo]}[]`;
    input.className   = 'form-control form-control-sm mb-2';
    input.placeholder = `${placeholders[tipo]} ${cantidad}`;
    contenedor.appendChild(input);
    input.focus();
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/planificaciones/show.blade.php ENDPATH**/ ?>