<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-clipboard2-check me-2"></i>Detalle de actividad asignada</h4>
        <p class="text-muted">
            <strong><?php echo e($asignacion->materia?->nombre); ?></strong>
            &mdash;
            <strong><?php echo e($asignacion->curso?->nombre_completo); ?></strong>
        </p>
    </div>
    <div class="col-auto">
        <a href="<?php echo e(route('asignaractividad.ver', ['materia_id' => $asignacion->materia_id, 'curso_id' => $asignacion->curso_id])); ?>"
           class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>


<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white fw-semibold">
        <i class="bi bi-info-circle me-1"></i>Datos de la asignación
    </div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-2">
                <div class="text-muted small">N° Unidad</div>
                <div class="fw-semibold"><?php echo e($asignacion->actividad?->numerounidad ?? '—'); ?></div>
            </div>
            <div class="col-md-2">
                <div class="text-muted small">N° Actividad</div>
                <div class="fw-semibold"><?php echo e($asignacion->actividad?->numeroactividad ?? '—'); ?></div>
            </div>
            <div class="col-md-4">
                <div class="text-muted small">Tipo</div>
                <div class="fw-semibold"><?php echo e($asignacion->actividad?->tipoactividad?->denominacion ?? '—'); ?></div>
            </div>
            <div class="col-md-4">
                <div class="text-muted small">Materia</div>
                <div class="fw-semibold"><?php echo e($asignacion->materia?->nombre ?? '—'); ?></div>
            </div>
            <div class="col-md-6">
                <div class="text-muted small">Tema</div>
                <div class="fw-semibold fs-5"><?php echo e($asignacion->actividad?->tema ?? '—'); ?></div>
            </div>
            <?php if($asignacion->actividad?->subtema): ?>
            <div class="col-md-6">
                <div class="text-muted small">Subtema</div>
                <div class="fw-semibold"><?php echo e($asignacion->actividad->subtema); ?></div>
            </div>
            <?php endif; ?>
            <div class="col-md-3">
                <div class="text-muted small">Fecha inicio</div>
                <div class="fw-semibold"><?php echo e($asignacion->fechainicio->format('d/m/Y')); ?></div>
            </div>
            <div class="col-md-3">
                <div class="text-muted small">Fecha entrega</div>
                <div class="fw-semibold text-danger"><?php echo e($asignacion->fechaentrega->format('d/m/Y')); ?></div>
            </div>
            <div class="col-md-3">
                <div class="text-muted small">Modalidad</div>
                <div>
                    <?php if($asignacion->esgrupal): ?>
                        <span class="badge bg-warning text-dark">
                            Grupal (<?php echo e($asignacion->integrantesporgrupo); ?> por grupo)
                        </span>
                    <?php else: ?>
                        <span class="badge bg-light text-dark">Individual</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-muted small">Estado</div>
                <span class="badge bg-<?php echo e($asignacion->estado === 'activa' ? 'success' : 'secondary'); ?> fs-6">
                    <?php echo e(ucfirst($asignacion->estado)); ?>

                </span>
            </div>
            <?php if($asignacion->actividad?->descripcion): ?>
            <div class="col-12">
                <div class="text-muted small">Observaciones</div>
                <div><?php echo e($asignacion->actividad->descripcion); ?></div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<?php if($asignacion->actividad?->items->isNotEmpty()): ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white fw-semibold">
        <i class="bi bi-list-ol me-1"></i>
        Consignas (<?php echo e($asignacion->actividad->items->count()); ?>)
    </div>
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th class="ps-4 text-center" style="width:100px">N° Item</th>
                    <th>Consigna / Pregunta</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $asignacion->actividad->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="ps-4 text-center fw-bold fs-5"><?php echo e($item->numeroitem); ?></td>
                    <td class="py-3"><?php echo e($item->texto); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>


<?php if($asignacion->esgrupal && $asignacion->actividad?->grupos->isNotEmpty()): ?>
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-semibold">
        <i class="bi bi-people me-1"></i>Grupos (<?php echo e($asignacion->actividad->grupos->count()); ?>)
    </div>
    <div class="card-body">
        <div class="row g-3">
            <?php $__currentLoopData = $asignacion->actividad->grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card border shadow-sm h-100">
                    <div class="card-header bg-primary text-white fw-semibold d-flex justify-content-between">
                        <span><?php echo e($grupo->nombre); ?></span>
                        <span class="badge bg-white text-primary">
                            <?php echo e($grupo->alumnos->count()); ?> integrantes
                        </span>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush">
                            <?php $__currentLoopData = $grupo->alumnos->sortBy('apellido'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <i class="bi bi-person me-1 text-muted"></i>
                                <?php echo e($alumno->nombre_completo); ?>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/asignaractividad/detalle.blade.php ENDPATH**/ ?>