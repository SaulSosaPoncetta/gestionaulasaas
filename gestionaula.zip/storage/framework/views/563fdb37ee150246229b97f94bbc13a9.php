<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-clipboard2-arrow me-2"></i>Asignar actividad</h4>
        <p class="text-muted">Seleccioná el curso y la materia para ver las actividades disponibles.</p>
        <?php if($cursoActivo): ?>
        <span class="badge bg-success mt-1">
            <i class="bi bi-play-circle me-1"></i>Clase activa detectada — curso y materia preseleccionados
        </span>
        <?php endif; ?>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('asignarnuevo.ver')); ?>">
            <div class="row g-3">

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        <span class="badge bg-primary me-1">1</span>Curso
                    </label>
                    <?php $haySep = false; ?>
                    <select name="curso_id" id="curso_id" class="form-select" required>
                        <option value="">Seleccioná un curso...</option>
                        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($c->id === $cursoActivo): ?>
                                <option value="<?php echo e($c->id); ?>" selected>
                                    ⚡ <?php echo e($c->nombre_completo); ?> (activo ahora)
                                </option>
                            <?php elseif($cursosEnHorario->contains($c->id)): ?>
                                <option value="<?php echo e($c->id); ?>" <?php echo e($cursoId == $c->id ? 'selected' : ''); ?>>
                                    📅 <?php echo e($c->nombre_completo); ?>

                                </option>
                            <?php else: ?>
                                <?php if(!$haySep): ?> <?php $haySep = true ?> <option disabled>──────────────</option> <?php endif; ?>
                                <option value="<?php echo e($c->id); ?>" <?php echo e($cursoId == $c->id ? 'selected' : ''); ?>>
                                    <?php echo e($c->nombre_completo); ?>

                                </option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($cursoActivo): ?>
                    <div class="form-text">
                        <i class="bi bi-lightning-charge-fill text-success me-1"></i>Activo ahora &nbsp;
                        <span>📅 En tu horario</span>
                    </div>
                    <?php endif; ?>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        <span class="badge bg-primary me-1">2</span>Materia
                    </label>
                    <select name="materia_id" id="materia_id" class="form-select" required
                            <?php echo e($materias->isEmpty() ? 'disabled' : ''); ?>>
                        <option value="">
                            <?php echo e($materias->isEmpty() ? 'Seleccioná primero un curso' : 'Seleccioná una materia...'); ?>

                        </option>
                        <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>"
                                <?php echo e($materiaActiva == $m->id ? 'selected' : ''); ?>>
                                <?php echo e($m->nombre); ?><?php echo e($materiaActiva == $m->id ? ' ⚡' : ''); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary"
                        <?php echo e($materias->isEmpty() ? 'disabled' : ''); ?>>
                    <i class="bi bi-arrow-right-circle me-1"></i>Ver actividades
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.getElementById('curso_id').addEventListener('change', function () {
    const cursoId   = this.value;
    const materiaEl = document.getElementById('materia_id');

    if (!cursoId) {
        materiaEl.innerHTML = '<option value="">Seleccioná primero un curso</option>';
        materiaEl.disabled  = true;
        return;
    }

    // Obtener materias del curso vía API de horarios
    materiaEl.innerHTML = '<option value="">Cargando materias...</option>';
    materiaEl.disabled  = true;

    fetch(`/api/cursos/${cursoId}/materias`)
        .then(r => r.json())
        .then(materias => {
            materiaEl.innerHTML = '<option value="">Seleccioná una materia...</option>';
            materias.forEach(m => {
                const sel   = m.activa ? ' selected' : '';
                const label = m.activa ? `${m.nombre} ⚡` : m.nombre;
                materiaEl.innerHTML += `<option value="${m.id}"${sel}>${label}</option>`;
            });
            materiaEl.disabled = materias.length === 0;
        })
        .catch(() => {
            materiaEl.innerHTML = '<option value="">Error al cargar</option>';
            materiaEl.disabled  = false;
        });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/asignarnuevo/index.blade.php ENDPATH**/ ?>