<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-person-check me-2"></i>Asistencia por alumno</h4>
    </div>
    <div class="col-auto">
        <a href="<?php echo e(route('asistencia.accion', array_filter([
            'curso_id'   => request('curso_id'),
            'materia_id' => request('materia_id'),
        ]))); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>


<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('asistencia.alumno')); ?>" class="row g-3">
            <input type="hidden" name="curso_id"   value="<?php echo e(request('curso_id')); ?>">
            <input type="hidden" name="materia_id" value="<?php echo e(request('materia_id')); ?>">

            <div class="col-md-5">
                <label class="form-label fw-semibold">Buscar alumno</label>
                <input type="text" name="buscar" class="form-control"
                       placeholder="Apellido, nombre o DNI..."
                       value="<?php echo e(request('buscar')); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Filtrar por materia</label>
                <select name="materia_id" class="form-select">
                    <option value="">— Todas las materias —</option>
                    <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($m->id); ?>"
                            <?php echo e(request('materia_id') == $m->id ? 'selected' : ''); ?>>
                            <?php echo e($m->nombre); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i>Buscar
                </button>
            </div>
        </form>
    </div>
</div>


<?php if($alumnos->isNotEmpty()): ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white fw-semibold">
        <i class="bi bi-people me-1"></i>Resultados (<?php echo e($alumnos->count()); ?>)
    </div>
    <div class="card-body p-0">
        <ul class="list-group list-group-flush">
            <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <div class="fw-semibold"><?php echo e($a->nombre_completo); ?></div>
                    <div class="text-muted small">
                        <?php echo e($a->curso?->nombre_completo ?? '—'); ?>

                    </div>
                </div>
                <a href="<?php echo e(route('asistencia.alumno', array_filter([
                        'alumno_id'  => $a->id,
                        'materia_id' => request('materia_id'),
                        'curso_id'   => request('curso_id'),
                    ]))); ?>"
                   class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-eye me-1"></i>Ver asistencias
                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php endif; ?>


<?php if($alumno): ?>


<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-success"><?php echo e($resumen['presente']); ?></div>
                <div class="text-muted small">Presentes</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-danger"><?php echo e($resumen['ausente']); ?></div>
                <div class="text-muted small">Ausentes</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-info"><?php echo e($resumen['justificado']); ?></div>
                <div class="text-muted small">Justificados</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-warning"><?php echo e($resumen['tarde']); ?></div>
                <div class="text-muted small">Tardanzas</div>
            </div>
        </div>
    </div>
</div>


<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-semibold d-flex justify-content-between">
        <span>
            <i class="bi bi-person me-1 text-primary"></i>
            <?php echo e($alumno->nombre_completo); ?>

            — <?php echo e($alumno->curso?->nombre_completo ?? '—'); ?>

        </span>
        <span class="badge bg-secondary"><?php echo e($resumen['total']); ?> registros</span>
    </div>
    <div class="card-body p-0">
        <?php if($detalle->isEmpty()): ?>
            <div class="p-4 text-center text-muted">
                <i class="bi bi-calendar-x fs-2 d-block mb-2"></i>
                No hay registros de asistencia para este alumno.
            </div>
        <?php else: ?>
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th class="ps-4">Fecha</th>
                    <th>Materia</th>
                    <th class="text-center">Estado</th>
                    <th>Hora llegada</th>
                    <th>Observación</th>
                    <th class="text-center">Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $detalle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="ps-4"><?php echo e($reg->fecha->format('d/m/Y')); ?></td>
                    <td><?php echo e($reg->materia?->nombre ?? '—'); ?></td>
                    <td class="text-center">
                        <span class="badge bg-<?php echo e($reg->estadobadge); ?>"><?php echo e($reg->estadolabel); ?></span>
                    </td>
                    <td>
                        <?php if($reg->estado === 'tarde' && $reg->horallegada): ?>
                            <span class="badge bg-warning text-dark">
                                <i class="bi bi-clock me-1"></i>
                                <?php echo e(\Carbon\Carbon::parse($reg->horallegada)->format('H:i')); ?>

                            </span>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-muted small"><?php echo e($reg->observacion ?? '—'); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('asistencia.editar', $reg)); ?>"
                           class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-pencil"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/asistencia/alumno.blade.php ENDPATH**/ ?>