<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GestiónAula — Sistema de gestión para docentes</title>
    
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#0d6efd">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="GestiónAula">
    <link rel="apple-touch-icon" href="/icons/icon-192x192.png">
    <link rel="icon" type="image/png" href="/icons/icon-192x192.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #0d6efd;
            --dark: #1a1a2e;
        }
        html { scroll-behavior: smooth; }
        body { font-family: 'Segoe UI', sans-serif; }

        /* Navbar */
        .navbar-landing { background: rgba(255,255,255,0.95); backdrop-filter: blur(10px); box-shadow: 0 2px 20px rgba(0,0,0,0.08); }

        /* Hero */
        .hero {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
        }
        .hero::before {
            content: '';
            position: absolute;
            width: 600px; height: 600px;
            background: radial-gradient(circle, rgba(13,110,253,0.15) 0%, transparent 70%);
            top: -200px; right: -200px;
        }
        .hero::after {
            content: '';
            position: absolute;
            width: 400px; height: 400px;
            background: radial-gradient(circle, rgba(13,110,253,0.1) 0%, transparent 70%);
            bottom: -100px; left: -100px;
        }
        .hero-badge {
            display: inline-block;
            background: rgba(13,110,253,0.2);
            border: 1px solid rgba(13,110,253,0.4);
            color: #74b9ff;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
            margin-bottom: 24px;
        }
        .hero h1 { font-size: 3.5rem; font-weight: 800; line-height: 1.1; }
        .hero h1 span { color: #74b9ff; }
        .btn-hero-primary {
            background: #0d6efd;
            color: white;
            padding: 14px 32px;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            border: none;
            transition: all 0.3s;
        }
        .btn-hero-primary:hover { background: #0a58ca; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(13,110,253,0.4); color: white; }
        .btn-hero-outline {
            background: transparent;
            color: white;
            padding: 14px 32px;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            border: 2px solid rgba(255,255,255,0.3);
            transition: all 0.3s;
        }
        .btn-hero-outline:hover { border-color: white; background: rgba(255,255,255,0.1); color: white; }

        /* Stats */
        .stats-bar { background: #0d6efd; }
        .stat-item { text-align: center; padding: 24px; }
        .stat-number { font-size: 2.5rem; font-weight: 800; color: white; }
        .stat-label { color: rgba(255,255,255,0.8); font-size: 14px; }

        /* Features */
        .feature-icon {
            width: 64px; height: 64px;
            background: linear-gradient(135deg, #e8f0fe, #d2e3fc);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            margin-bottom: 16px;
        }
        .feature-card {
            padding: 32px;
            border-radius: 16px;
            border: 1px solid #e9ecef;
            transition: all 0.3s;
            height: 100%;
        }
        .feature-card:hover { transform: translateY(-4px); box-shadow: 0 12px 40px rgba(0,0,0,0.1); border-color: #0d6efd; }

        /* Plan cards */
        .plan-card {
            border-radius: 20px;
            border: 2px solid #e9ecef;
            transition: all 0.3s;
            overflow: hidden;
        }
        .plan-card:hover { transform: translateY(-8px); box-shadow: 0 20px 60px rgba(0,0,0,0.12); }
        .plan-card.featured { border-color: #0d6efd; }
        .plan-card.featured .plan-header { background: #0d6efd; color: white; }
        .plan-price { font-size: 3rem; font-weight: 800; }
        .plan-period { font-size: 14px; color: #6c757d; }
        .btn-plan { padding: 12px 32px; border-radius: 50px; font-weight: 600; text-decoration: none; display: block; text-align: center; }

        /* Contact */
        .contact-section { background: #f8f9fa; }
        .contact-form { background: white; border-radius: 20px; padding: 40px; box-shadow: 0 4px 30px rgba(0,0,0,0.06); }
        .form-control-lg { border-radius: 10px; border: 2px solid #e9ecef; }
        .form-control-lg:focus { border-color: #0d6efd; box-shadow: 0 0 0 4px rgba(13,110,253,0.1); }

        /* Footer */
        footer { background: #1a1a2e; }
    </style>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-landing fixed-top">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary fs-4" href="#inicio">
            <i class="bi bi-mortarboard-fill me-2"></i>GestiónAula
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navLanding">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navLanding">
            <ul class="navbar-nav mx-auto gap-2">
                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="#inicio">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="#producto">Producto</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="#planes">Planes</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="#contacto">Contacto</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-primary" href="#descargar">
                        <i class="bi bi-download me-1"></i>Instalar app
                    </a>
                </li>
            </ul>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary rounded-pill px-4">
                    <i class="bi bi-box-arrow-in-right me-1"></i>Iniciar sesión
                </a>
                <a href="#planes" class="btn btn-primary rounded-pill px-4">
                    <i class="bi bi-rocket me-1"></i>Suscribirse
                </a>
            </div>
        </div>
    </div>
</nav>


<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-5"
     style="z-index:9999;min-width:400px">
    <i class="bi bi-check-circle me-2"></i><?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>


<section id="inicio" class="hero">
    <div class="container position-relative" style="z-index:1">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="hero-badge">
                    <i class="bi bi-stars me-1"></i>Nuevo sistema para docentes
                </div>
                <h1 class="text-white mb-4">
                    Gestioná tu <span>aula</span> de forma inteligente
                </h1>
                <p class="text-white-50 fs-5 mb-5">
                    GestiónAula es el sistema integral que los docentes necesitaban.
                    Asistencia, calificaciones, actividades, planificaciones y mucho más
                    en un solo lugar.
                </p>
                <div class="d-flex gap-3 flex-wrap">
                    <a href="#planes" class="btn-hero-primary">
                        <i class="bi bi-rocket me-2"></i>Empezar gratis
                    </a>
                    <a href="#producto" class="btn-hero-outline">
                        <i class="bi bi-play-circle me-2"></i>Ver características
                    </a>
                </div>
            </div>
            <div class="col-lg-6 text-center mt-5 mt-lg-0">
                <div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:32px">
                    <div class="row g-3">
                        <?php $__currentLoopData = [
                            ['bi-person-check','Asistencia','Registro en segundos'],
                            ['bi-journal-text','Calificaciones','Notas siempre a mano'],
                            ['bi-clipboard2-check','Actividades','Gestión completa'],
                            ['bi-calendar3','Horarios','Detección automática'],
                            ['bi-graph-up','Estadísticas','En tiempo real'],
                            ['bi-folder2-open','Proyectos','Con carpeta de campo'],
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-4">
                            <div style="background:rgba(255,255,255,0.08);border-radius:12px;padding:16px;color:white">
                                <i class="bi <?php echo e($feat[0]); ?> fs-2 d-block mb-1 text-primary" style="color:#74b9ff!important"></i>
                                <div style="font-size:11px;font-weight:600"><?php echo e($feat[1]); ?></div>
                                <div style="font-size:10px;opacity:0.6"><?php echo e($feat[2]); ?></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="stats-bar">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = [
                ['bi-people','Módulos completos','15+'],
                ['bi-shield-check','Datos seguros','100%'],
                ['bi-clock','Ahorro de tiempo','3hs/semana'],
                ['bi-star','Satisfacción','⭐⭐⭐⭐⭐'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-md-3">
                <div class="stat-item">
                    <div class="stat-number"><?php echo e($stat[2]); ?></div>
                    <div class="stat-label"><i class="bi <?php echo e($stat[0]); ?> me-1"></i><?php echo e($stat[1]); ?></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section id="producto" class="py-6" style="padding:80px 0">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill mb-3">
                Características
            </span>
            <h2 class="fw-bold fs-1 mb-3">Todo lo que un docente necesita</h2>
            <p class="text-muted fs-5 mx-auto" style="max-width:600px">
                GestiónAula reemplaza las planillas en papel, los cuadernos y las hojas de cálculo
                con un sistema moderno y fácil de usar.
            </p>
        </div>

        <div class="row g-4">
            <?php $__currentLoopData = [
                ['bi-person-check','Asistencia digital','Registrá presente, ausente, tarde y justificado. El sistema calcula porcentajes y alertas automáticamente.','success'],
                ['bi-journal-text','Calificaciones','Notas por período y tipo de evaluación. Historial completo por alumno con todas las fuentes.','primary'],
                ['bi-clipboard2-check','Actividades pedagógicas','Creá actividades, asignalas por curso, gestioná grupos y calificá desde un solo lugar.','warning'],
                ['bi-calendar3','Horarios inteligentes','El sistema detecta automáticamente en qué clase estás y te muestra el próximo establecimiento.','info'],
                ['bi-calculator','Prenotas automáticas','Calculá prenotas combinando calificaciones, actividades y asistencia con un clic.','danger'],
                ['bi-folder2-open','Proyectos y carpeta de campo','Gestioná proyectos con carpeta digital individual por alumno con notas, imágenes y documentos.','secondary'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="bi <?php echo e($f[0]); ?> text-<?php echo e($f[3]); ?>"></i>
                    </div>
                    <h5 class="fw-bold mb-2"><?php echo e($f[1]); ?></h5>
                    <p class="text-muted mb-0"><?php echo e($f[2]); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section id="planes" class="py-5" style="background:#f8f9fa;padding:80px 0!important">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill mb-3">
                Precios
            </span>
            <h2 class="fw-bold fs-1 mb-3">Elegí el plan que mejor se adapta</h2>
            <p class="text-muted fs-5">Todos los planes incluyen acceso completo al sistema.</p>
        </div>

        <?php if($planes->isEmpty()): ?>
        <div class="alert alert-info text-center">No hay planes disponibles en este momento.</div>
        <?php else: ?>
        <div class="row g-4 justify-content-center">
            <?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $featured = $index === 1 || $planes->count() === 1; ?>
            <div class="col-md-6 col-lg-4">
                <div class="plan-card <?php echo e($featured ? 'featured' : ''); ?>">
                    <div class="plan-header p-4 <?php echo e($featured ? '' : 'bg-light'); ?>">
                        <?php if($featured): ?>
                        <span class="badge bg-warning text-dark mb-2">Más popular</span>
                        <?php endif; ?>
                        <h4 class="fw-bold mb-0 <?php echo e($featured ? 'text-white' : ''); ?>"><?php echo e($plan->nombre); ?></h4>
                        <?php if($plan->descripcion): ?>
                        <p class="mb-0 mt-1 small <?php echo e($featured ? 'text-white-50' : 'text-muted'); ?>">
                            <?php echo e($plan->descripcion); ?>

                        </p>
                        <?php endif; ?>
                    </div>
                    <div class="p-4">
                        <div class="d-flex align-items-end gap-1 mb-4">
                            <span class="plan-price text-<?php echo e($featured ? 'primary' : 'dark'); ?>">
                                $<?php echo e(number_format($plan->precio, 0, ',', '.')); ?>

                            </span>
                            <span class="plan-period mb-2">/ <?php echo e($plan->periodicidad); ?></span>
                        </div>

                        <ul class="list-unstyled mb-4">
                            <?php $__currentLoopData = ['Acceso completo al sistema','Asistencia y calificaciones','Actividades y proyectos','Soporte incluido','Actualizaciones gratuitas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-2">
                                <i class="bi bi-check-circle-fill text-success me-2"></i><?php echo e($item); ?>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                        <button class="btn btn-plan <?php echo e($featured ? 'btn-primary' : 'btn-outline-primary'); ?>"
                                onclick="seleccionarPlan(<?php echo e($plan->id); ?>, '<?php echo e($plan->nombre); ?>', <?php echo e($plan->precio); ?>, '<?php echo e($plan->periodicidad); ?>')">
                            <i class="bi bi-rocket me-1"></i>Elegir este plan
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</section>


<section id="contacto" class="contact-section" style="padding:80px 0">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="text-center mb-5">
                    <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill mb-3">
                        Contacto
                    </span>
                    <h2 class="fw-bold fs-1 mb-3">Tenes alguna consulta?</h2>
                    <p class="text-muted fs-5">Completá el formulario y te responderemos a la brevedad.</p>
                </div>

                <div class="contact-form">
                    <form method="POST" action="<?php echo e(route('landing.contacto')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Apellido y nombre <span class="text-danger">*</span></label>
                                <input type="text" name="nombre" class="form-control form-control-lg"
                                       value="<?php echo e(old('nombre')); ?>" placeholder="Tu nombre completo" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Teléfono</label>
                                <input type="text" name="telefono" class="form-control form-control-lg"
                                       value="<?php echo e(old('telefono')); ?>" placeholder="Ej: 2284-123456">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control form-control-lg"
                                       value="<?php echo e(old('email')); ?>" placeholder="tu@email.com" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Mensaje <span class="text-danger">*</span></label>
                                <textarea name="mensaje" class="form-control form-control-lg" rows="5"
                                          placeholder="Escribi tu consulta..." required><?php echo e(old('mensaje')); ?></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary btn-lg w-100 rounded-pill">
                                    <i class="bi bi-send me-2"></i>Enviar mensaje
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>


<section id="descargar" class="py-5" style="background:linear-gradient(135deg,#1565c0 0%,#0d47a1 100%);padding:80px 0!important">
    <div class="container text-center text-white">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <div class="mb-3">
                    <img src="/icons/icon-192x192.png" width="80" height="80" class="rounded-3 shadow mb-3" alt="GestiónAula">
                </div>
                <h2 class="fw-bold mb-3" style="font-size:2rem">
                    Llevá GestiónAula siempre con vos
                </h2>
                <p class="fs-5 mb-4" style="opacity:.9">
                    Instalala como app en tu dispositivo. Sin tiendas, sin descargas enormes,<br>
                    siempre actualizada y funciona sin conexión.
                </p>

                
                <div class="mb-5" id="bloque-instalar">

                    
                    <div id="estado-prompt" style="display:none">
                        <button type="button" id="landing-install-btn"
                                class="btn btn-light btn-lg px-5 fw-bold shadow me-3" style="color:#0d47a1;font-size:1.1rem">
                            <i class="bi bi-download me-2"></i>Instalar en este dispositivo
                        </button>
                        <p class="mt-3 small" style="opacity:.75">Chrome / Edge detectó que podés instalar la app ahora mismo.</p>
                    </div>

                    
                    <div id="estado-instalada" style="display:none">
                        <div class="alert alert-success d-inline-flex align-items-center gap-2 px-4 py-3" style="font-size:1rem">
                            <i class="bi bi-check-circle-fill fs-4"></i>
                            <span><strong>GestiónAula ya está instalada</strong> en este dispositivo.</span>
                        </div>
                    </div>

                    
                    <div id="estado-manual">
                        <div class="row g-3 mb-4">
                            <div class="col-md-4">
                                <div class="p-4 rounded-4 h-100" style="background:rgba(255,255,255,.13)">
                                    <div style="font-size:2.2rem" class="mb-2">🤖</div>
                                    <h6 class="fw-bold">Android (Chrome)</h6>
                                    <p class="small mb-2" style="opacity:.85">Menú <strong>⋮</strong> → <strong>"Agregar a pantalla de inicio"</strong></p>
                                    <span class="badge bg-success">Automático disponible</span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-4 rounded-4 h-100" style="background:rgba(255,255,255,.13)">
                                    <div style="font-size:2.2rem" class="mb-2">🍎</div>
                                    <h6 class="fw-bold">iPhone / iPad (Safari)</h6>
                                    <p class="small mb-2" style="opacity:.85">Toque <strong>⬆ Compartir</strong> → <strong>"Agregar a inicio"</strong></p>
                                    <span class="badge bg-warning text-dark">Manual</span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-4 rounded-4 h-100" style="background:rgba(255,255,255,.13)">
                                    <div style="font-size:2.2rem" class="mb-2">🖥️</div>
                                    <h6 class="fw-bold">PC Windows / Mac</h6>
                                    <p class="small mb-2" style="opacity:.85">Chrome/Edge → ícono <strong>⊕</strong> en la barra de dirección</p>
                                    <span class="badge bg-success">Automático disponible</span>
                                </div>
                            </div>
                        </div>
                        <p class="small mt-2" style="opacity:.7">
                            <i class="bi bi-info-circle me-1"></i>
                            Para instalación automática usá <strong>Google Chrome</strong> o <strong>Microsoft Edge</strong>.
                        </p>
                    </div>

                </div>

                <div class="d-flex flex-wrap justify-content-center gap-3">
                    <a href="<?php echo e(route('register')); ?>"
                       class="btn btn-light btn-lg px-5 fw-bold" style="color:#0d47a1">
                        <i class="bi bi-person-plus me-2"></i>Crear cuenta gratis
                    </a>
                    <a href="<?php echo e(route('login')); ?>"
                       class="btn btn-outline-light btn-lg px-4">
                        <i class="bi bi-box-arrow-in-right me-2"></i>Iniciar sesión
                    </a>
                    
                    <a href="#descarga-desktop"
                       class="btn btn-outline-light btn-lg px-4">
                        <i class="bi bi-display me-2"></i>App de escritorio (.exe)
                    </a>
                </div>

                <div class="mt-4 small" style="opacity:.7">
                    <i class="bi bi-shield-check me-1"></i>Sin descarga desde tiendas &nbsp;·&nbsp;
                    <i class="bi bi-arrow-repeat me-1"></i>Siempre actualizada &nbsp;·&nbsp;
                    <i class="bi bi-wifi-off me-1"></i>Funciona sin conexión
                </div>
            </div>
        </div>
    </div>
</section>


<section id="descarga-desktop" class="py-5" style="background:#f8f9fa;padding:60px 0!important">
    <div class="container">
        <div class="row justify-content-center align-items-center g-5">
            <div class="col-lg-6">
                <span class="badge bg-primary mb-3">Versión de escritorio</span>
                <h2 class="fw-bold mb-3">GestiónAula para Windows</h2>
                <p class="text-muted mb-4">
                    Instalá la versión nativa para PC. Funciona <strong>sin navegador</strong>,
                    guarda datos localmente cuando no tenés internet y los sincroniza
                    automáticamente cuando recuperás la conexión.
                </p>
                <ul class="list-unstyled mb-4">
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Sin navegador requerido</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Funciona 100% offline</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Sincronización automática al recuperar conexión</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Actualizaciones automáticas</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Acceso directo desde el escritorio</li>
                </ul>
                <div class="d-flex gap-3 flex-wrap">
                    <a href="/descarga/GestionAula-Setup.exe" id="btn-descarga-exe"
                       class="btn btn-primary btn-lg px-4">
                        <i class="bi bi-windows me-2"></i>Descargar para Windows
                        <span class="badge bg-light text-primary ms-2">v1.0</span>
                    </a>
                    <a href="#" class="btn btn-outline-secondary btn-lg px-4" disabled style="opacity:.5;pointer-events:none">
                        <i class="bi bi-apple me-2"></i>Mac — Próximamente
                    </a>
                </div>
                <p class="text-muted small mt-3">
                    <i class="bi bi-info-circle me-1"></i>
                    Requiere Windows 10 o superior. Tamaño: ~90 MB.
                </p>
            </div>
            <div class="col-lg-5 text-center">
                <div class="p-5 rounded-4 shadow-sm" style="background:linear-gradient(135deg,#e8f4fd,#f0f7ff)">
                    <div style="font-size:5rem">🖥️</div>
                    <div class="mt-3 fw-bold fs-5">GestiónAula Desktop</div>
                    <div class="text-muted small">Versión 1.0 — Windows 10+</div>
                    <div class="mt-3 d-flex justify-content-center gap-2 flex-wrap">
                        <span class="badge bg-success">Offline</span>
                        <span class="badge bg-primary">Auto-sincronización</span>
                        <span class="badge bg-info">Auto-update</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<footer class="py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-white">
                <i class="bi bi-mortarboard-fill me-2 text-primary"></i>
                <strong>GestiónAula</strong> &copy; <?php echo e(date('Y')); ?>

            </div>
            <div class="col-md-6 text-end">
                <a href="<?php echo e(route('login')); ?>" class="text-white-50 text-decoration-none me-3">
                    <i class="bi bi-box-arrow-in-right me-1"></i>Iniciar sesión
                </a>
                <a href="#contacto" class="text-white-50 text-decoration-none">
                    <i class="bi bi-envelope me-1"></i>Contacto
                </a>
            </div>
        </div>
    </div>
</footer>


<div class="modal fade" id="modalRegistro" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-header border-0 pb-0">
                <div>
                    <h4 class="fw-bold mb-1">Crear cuenta</h4>
                    <p class="text-muted mb-0" id="modalPlanNombre"></p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formRegistro">
                    <input type="hidden" id="reg_plan_id" name="plan_id">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label fw-semibold">Nombre completo <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="reg_name" class="form-control form-control-lg"
                                   placeholder="Tu nombre completo" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" id="reg_email" class="form-control form-control-lg"
                                   placeholder="tu@email.com" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Contraseña <span class="text-danger">*</span></label>
                            <input type="password" name="password" id="reg_pass" class="form-control form-control-lg"
                                   placeholder="Minimo 8 caracteres" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Confirmar contraseña <span class="text-danger">*</span></label>
                            <input type="password" name="password_confirmation" class="form-control form-control-lg"
                                   placeholder="Repeti la contraseña" required>
                        </div>
                        <div class="col-12">
                            <div id="planResumen" class="p-3 rounded-3"
                                 style="background:#f0f7ff;border:1px solid #d2e3fc">
                            </div>
                        </div>
                        <div id="regError" class="col-12 d-none">
                            <div class="alert alert-danger mb-0" id="regErrorMsg"></div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-outline-secondary rounded-pill px-4"
                        data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary rounded-pill px-5" onclick="confirmarRegistro()">
                    <i class="bi bi-check-circle me-1"></i>Continuar
                </button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="modalConfirmacion" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-body text-center p-5">
                <div class="mb-3" style="font-size:64px">📋</div>
                <h4 class="fw-bold mb-3">Confirmar registro</h4>
                <div id="resumenTransaccion" class="text-start mb-4"></div>
                <div class="d-grid gap-2">
                    <button class="btn btn-primary btn-lg rounded-pill" onclick="procesarRegistro()">
                        <i class="bi bi-check-circle me-2"></i>Confirmar y registrarme
                    </button>
                    <button class="btn btn-outline-secondary rounded-pill"
                            data-bs-dismiss="modal">Modificar datos</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="modalExito" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-body text-center p-5">
                <div class="mb-3" style="font-size:64px">✅</div>
                <h4 class="fw-bold mb-2">Registro exitoso</h4>
                <p class="text-muted mb-4">
                    Te enviamos un mail de activación a <strong id="exitoEmail"></strong>.
                    Revisá tu bandeja de entrada y hacé clic en el link para activar tu cuenta.
                </p>
                <a href="<?php echo e(route('landing.index')); ?>" class="btn btn-primary rounded-pill px-5">
                    Volver al inicio
                </a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
let planSeleccionado = null;

function seleccionarPlan(id, nombre, precio, periodicidad) {
    planSeleccionado = { id, nombre, precio, periodicidad };

    document.getElementById('reg_plan_id').value = id;
    document.getElementById('modalPlanNombre').innerHTML =
        `<span class="badge bg-primary">${nombre}</span> — $${precio.toLocaleString('es-AR')} / ${periodicidad}`;
    document.getElementById('planResumen').innerHTML = `
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <div class="fw-semibold">Plan ${nombre}</div>
                <div class="text-muted small">${periodicidad}</div>
            </div>
            <div class="fw-bold text-primary fs-5">$${precio.toLocaleString('es-AR')}</div>
        </div>`;

    document.getElementById('regError').classList.add('d-none');
    new bootstrap.Modal(document.getElementById('modalRegistro')).show();
}

function confirmarRegistro() {
    const form    = document.getElementById('formRegistro');
    const name    = document.getElementById('reg_name').value.trim();
    const email   = document.getElementById('reg_email').value.trim();
    const pass    = document.getElementById('reg_pass').value;

    if (!name || !email || !pass) {
        document.getElementById('regError').classList.remove('d-none');
        document.getElementById('regErrorMsg').textContent = 'Completa todos los campos obligatorios.';
        return;
    }

    document.getElementById('resumenTransaccion').innerHTML = `
        <table class="table table-sm">
            <tr><td class="text-muted">Nombre</td><td class="fw-semibold">${name}</td></tr>
            <tr><td class="text-muted">Email</td><td class="fw-semibold">${email}</td></tr>
            <tr><td class="text-muted">Plan</td><td><span class="badge bg-primary">${planSeleccionado.nombre}</span></td></tr>
            <tr><td class="text-muted">Monto</td><td class="fw-semibold text-primary">$${planSeleccionado.precio.toLocaleString('es-AR')} / ${planSeleccionado.periodicidad}</td></tr>
        </table>
        <div class="alert alert-info small mb-0">
            <i class="bi bi-info-circle me-1"></i>
            Recibirás un email de activación en <strong>${email}</strong> para activar tu cuenta.
        </div>`;

    bootstrap.Modal.getInstance(document.getElementById('modalRegistro')).hide();
    setTimeout(() => {
        new bootstrap.Modal(document.getElementById('modalConfirmacion')).show();
    }, 400);
}

function procesarRegistro() {
    const form = document.getElementById('formRegistro');
    const formData = new FormData(form);

    bootstrap.Modal.getInstance(document.getElementById('modalConfirmacion')).hide();

    fetch('<?php echo e(route("landing.registrar")); ?>', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            'Accept': 'application/json',
        },
        body: formData,
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            document.getElementById('exitoEmail').textContent = data.email;
            setTimeout(() => {
                new bootstrap.Modal(document.getElementById('modalExito')).show();
            }, 400);
        } else {
            alert(data.message || 'Error al registrar. Intentá de nuevo.');
        }
    })
    .catch(() => alert('Error de conexion. Intentá de nuevo.'));
}
</script>

<script>
// PWA: Registrar Service Worker
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(reg => console.log('[PWA] SW registrado'))
        .catch(err => console.warn('[PWA] SW error:', err));
}

// ── Estados de instalación PWA ────────────────────────────────────
const elPrompt   = document.getElementById('estado-prompt');
const elManual   = document.getElementById('estado-manual');
const elInstal   = document.getElementById('estado-instalada');
const installBtn = document.getElementById('landing-install-btn');
let   deferred   = null;

function mostrar(estado) {
    elPrompt && (elPrompt.style.display = 'none');
    elManual && (elManual.style.display = 'none');
    elInstal && (elInstal.style.display = 'none');
    if (estado === 'prompt')   elPrompt && (elPrompt.style.display = 'block');
    if (estado === 'manual')   elManual && (elManual.style.display = 'block');
    if (estado === 'instalada') elInstal && (elInstal.style.display = 'block');
}

// Detectar si ya está instalada como PWA
if (window.matchMedia('(display-mode: standalone)').matches ||
    window.navigator.standalone === true) {
    mostrar('instalada');
} else {
    // Por defecto mostramos instrucciones manuales
    mostrar('manual');
}

// Chrome/Edge detectan que se puede instalar
window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferred = e;
    mostrar('prompt'); // Mostrar botón de 1 click
});

// Click en botón de instalación directa
if (installBtn) {
    installBtn.addEventListener('click', async () => {
        if (!deferred) return;
        installBtn.disabled = true;
        installBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Instalando...';
        deferred.prompt();
        const { outcome } = await deferred.userChoice;
        deferred = null;
        if (outcome === 'accepted') {
            mostrar('instalada');
        } else {
            installBtn.disabled = false;
            installBtn.innerHTML = '<i class="bi bi-download me-2"></i>Instalar en este dispositivo';
        }
    });
}

// App instalada con éxito
window.addEventListener('appinstalled', () => {
    mostrar('instalada');
});
</script>
</body>
</html><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/landing/index.blade.php ENDPATH**/ ?>