<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Gestión Aula')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#0d6efd">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="GestiónAula">
    <link rel="apple-touch-icon" href="/icons/icon-192.png">
    <link rel="icon" type="image/png" href="/icons/icon-192.png">
    <style>
        @keyframes pulse-dot { 0%,100%{opacity:1} 50%{opacity:.25} }
        @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
    </style>
</head>

<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?php echo e(route('dashboard')); ?>">
                <i class="bi bi-mortarboard-fill me-2"></i>Gestión Aula
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <?php if(auth()->guard()->check()): ?>
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle <?php echo e(request()->routeIs('asistencia.*') || request()->routeIs('calificaciones.*') ? 'active' : ''); ?>"
                                href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-calendar2-check me-1"></i>Act. áulica
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('asistencia.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('asistencia.index')); ?>">
                                        <i class="bi bi-person-check me-2"></i>Asistencia
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('asignaractividad.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('asignaractividad.seleccionar')); ?>">
                                        <i class="bi bi-journal me-2"></i>Act. Asignadas
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('calificaractividad.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('calificaractividad.index')); ?>">
                                        <i class="bi bi-journal-check me-2"></i>Calificar actividades
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('calificaciones.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('calificaciones.index')); ?>">
                                        <i class="bi bi-journal-text me-2"></i>Calificar
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('prenotas.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('prenotas.index')); ?>">
                                        <i class="bi bi-calculator me-2"></i>Prenotas
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('cierre_cuatri.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('cierre_cuatri.index')); ?>">
                                        <i class="bi bi-calculator me-2"></i>Cierre de notas
                                    </a>
                                </li>


                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('librotemas.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('librotemas.index')); ?>">
                                        <i class="bi bi-journal-bookmark-fill me-2"></i>Libro de temas
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('pdf.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('pdf.index')); ?>">
                                        <i class="bi bi-printer me-2"></i>Impresiones PDF
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('excel.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('excel.index')); ?>">
                                        <i class="bi bi-file-earmark-spreadsheet me-2"></i>Exportar Excel
                                    </a>
                                </li>
                            </ul>
                        </li>

                        


                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle <?php echo e(request()->routeIs('tareas.*') || request()->routeIs('materialteoricoarchivos.*') ? 'active' : ''); ?>"
                                href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-folder2-open me-1"></i>Mat. pedagógico
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('contenidos.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('contenidos.index')); ?>">
                                        <i class="bi bi-journal-richtext me-1"></i>Contenidos
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('materialteoricoarchivos.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('materialteoricoarchivos.index')); ?>">
                                        <i class="bi bi-file-earmark-pdf me-2"></i>Material teórico
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('tiposactividad.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('tiposactividad.index')); ?>">
                                        <i class="bi bi-activity me-2"></i>Tipos de actividad
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('actividades.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('actividades.index')); ?>">
                                        <i class="bi bi-clipboard2-check me-2"></i>Actividades
                                    </a>
                                </li>

                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('asignarnuevo.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('asignarnuevo.index')); ?>">
                                        <i class="bi bi-journal me-2"></i>Asignar Act.
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('proyectos.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('proyectos.index')); ?>">
                                        <i class="bi bi-folder2-open me-2"></i>Proyectos
                                    </a>
                                </li>
                            </ul>
                        </li>

                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle <?php echo e(request()->routeIs('cursos.*') ||
                            request()->routeIs('materias.*') ||
                            request()->routeIs('alumnos.*') ||
                            request()->routeIs('niveles.*') ||
                            request()->routeIs('establecimientos.*') ||
                            request()->routeIs('ciclos.*') ||
                            request()->routeIs('areasformacion.*') ||
                            request()->routeIs('especialidades.*') ||
                            request()->routeIs('horarios.*') ||
                            request()->routeIs('declaracion.*') ||
                            request()->routeIs('planificaciones.*')
                                ? 'active'
                                : ''); ?>"
                                href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-gear me-1"></i>Administración
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item" href="<?php echo e(route('ciclos_lectivos.index')); ?>">
                                        <i class="bi bi-calendar2-range me-1"></i>Ciclos lectivos
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('calendarioescolar.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('calendarioescolar.index')); ?>">
                                        <i class="bi bi-calendar3 me-2"></i>Calendario escolar
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <h6 class="dropdown-header">Académico</h6>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('periodos.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('periodos.index')); ?>">
                                        <i class="bi bi-calendar3 me-2"></i>Períodos
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('cursos.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('cursos.index')); ?>">
                                        <i class="bi bi-building me-2"></i>Cursos
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('materias.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('materias.index')); ?>">
                                        <i class="bi bi-book me-2"></i>Materias
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('alumnos.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('alumnos.index')); ?>">
                                        <i class="bi bi-people me-2"></i>Alumnos
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('planificaciones.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('planificaciones.index')); ?>">
                                        <i class="bi bi-journal-bookmark me-2"></i>Planificación
                                    </a>
                                </li>

                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <h6 class="dropdown-header">Horarios</h6>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('designaciones.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('designaciones.index')); ?>">
                                        <i class="bi bi-file-earmark-person me-2"></i>Designaciones
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('horarios.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('horarios.index')); ?>">
                                        <i class="bi bi-calendar3 me-2"></i>Horarios
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('declaracion.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('declaracion.index')); ?>">
                                        <i class="bi bi-file-earmark-text me-2"></i>Declaración jurada
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('ceses.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('ceses.index')); ?>">
                                        <i class="bi bi-calendar-x me-2"></i>Ceses
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <h6 class="dropdown-header">Institucional</h6>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('niveles.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('niveles.index')); ?>">
                                        <i class="bi bi-diagram-3 me-2"></i>Niveles educativos
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('establecimientos.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('establecimientos.index')); ?>">
                                        <i class="bi bi-building me-2"></i>Establecimientos
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('periodos.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('periodos.index')); ?>">
                                        <i class="bi bi-calendar3 me-2"></i>Períodos
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>

                                <li>
                                    <h6 class="dropdown-header">Evaluación</h6>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('tiposevaluacion.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('tiposevaluacion.index')); ?>">
                                        <i class="bi bi-card-checklist me-2"></i>Tipos de evaluación
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('tipovaloraciones.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('tipovaloraciones.index')); ?>">
                                        <i class="bi bi-star me-2"></i>Tipos de valoración
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <h6 class="dropdown-header">Clasificación</h6>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('ciclos.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('ciclos.index')); ?>">
                                        <i class="bi bi-arrow-repeat me-2"></i>Ciclos
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('areasformacion.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('areasformacion.index')); ?>">
                                        <i class="bi bi-collection me-2"></i>Áreas de formación
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item <?php echo e(request()->routeIs('especialidades.*') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('especialidades.index')); ?>">
                                        <i class="bi bi-star me-2"></i>Especialidades
                                    </a>
                                </li>

                            </ul>

                        </li>


                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('comunicacion.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('comunicacion.index')); ?>">
                                <i class="bi bi-chat-dots me-1"></i>Comunicación
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('pagos.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('pagos.index')); ?>">
                                <i class="bi bi-credit-card me-2"></i>Susc.
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>

                <ul class="navbar-nav ms-auto">
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle me-1"></i><?php echo e(auth()->user()->name); ?>

                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <span class="dropdown-item-text text-muted small">
                                        <i class="bi bi-envelope me-1"></i><?php echo e(auth()->user()->email); ?>

                                    </span>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item text-danger">
                                            <i class="bi bi-box-arrow-right me-2"></i>Cerrar sesión
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item d-flex align-items-center gap-2 ms-2">

                        
                        <span id="badge-conexion"
                              title="Estado de conexión a internet"
                              style="cursor:default;font-size:11px;font-weight:600;padding:4px 10px;border-radius:20px;display:inline-flex;align-items:center;gap:5px;transition:all .3s;background:#198754;color:white">
                            <span id="badge-conexion-dot" style="width:8px;height:8px;border-radius:50%;background:white;display:inline-block"></span>
                            <span id="badge-conexion-texto">Conecc.</span>
                        </span>

                        
                        <span id="badge-sync"
                              title="Estado de sincronización de datos"
                              style="cursor:pointer;font-size:11px;font-weight:600;padding:4px 10px;border-radius:20px;display:inline-flex;align-items:center;gap:5px;transition:all .3s;background:#198754;color:white"
                              onclick="if(typeof OfflineManager!=='undefined') OfflineManager.sincronizar()">
                            <i id="badge-sync-icono" class="bi bi-check-circle-fill" style="font-size:10px"></i>
                            <span id="badge-sync-texto">Sincro.</span>
                        </span>

                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container py-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i><?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="bg-white border-top mt-auto py-3">
        <div class="container text-center text-muted small">
            <i class="bi bi-mortarboard me-1"></i>Sistema de Gestión de Aula &copy; <?php echo e(date('Y')); ?>

        </div>
    </footer>

    <?php echo $__env->make('partials.modal-confirm', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>

    
    <script src="/js/offline-manager.js"></script>
    <div id="pwa-banner" style="display:none;position:fixed;bottom:20px;right:20px;z-index:9999;max-width:310px">
        <div class="card border-0 shadow-lg" style="border-left:4px solid #0d6efd!important">
            <div class="card-body py-3 px-3">
                <div class="d-flex align-items-start gap-2">
                    <img src="/icons/icon-192.png" width="42" height="42" class="rounded-2 flex-shrink-0" alt="GA">
                    <div>
                        <div class="fw-bold" style="font-size:13px">Instalar GestiónAula</div>
                        <div class="text-muted" style="font-size:11px;line-height:1.4">Instalala como app para acceso rápido sin abrir el navegador.</div>
                        <div class="d-flex gap-2 mt-2">
                            <button id="pwa-install-btn" class="btn btn-primary btn-sm"><i class="bi bi-download me-1"></i>Instalar</button>
                            <button id="pwa-dismiss-btn" class="btn btn-outline-secondary btn-sm">Ahora no</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/sw.js', { scope: '/' })
                .then(reg => {
                    reg.addEventListener('updatefound', () => {
                        const sw = reg.installing;
                        sw.addEventListener('statechange', () => {
                            if (sw.state === 'installed' && navigator.serviceWorker.controller) {
                                pwaToast('🔄 Nueva versión disponible — <button class="btn btn-sm btn-light ms-1" onclick="location.reload()">Actualizar</button>', 'bg-info');
                            }
                        });
                    });
                });
            navigator.serviceWorker.addEventListener('controllerchange', () => location.reload());
            navigator.serviceWorker.addEventListener('message', e => {
                if (e.data?.tipo === 'CONEXION_RECUPERADA') pwaToast('✅ Conexión recuperada', 'bg-success');
            });
        });
    }
    window.addEventListener('online',  () => pwaToast('✅ Conexión recuperada', 'bg-success'));
    window.addEventListener('offline', () => pwaToast('⚠️ Sin conexión — modo offline', 'bg-warning text-dark'));

    let _pwaPrompt = null;
    const _banner  = document.getElementById('pwa-banner');
    window.addEventListener('beforeinstallprompt', e => {
        e.preventDefault(); _pwaPrompt = e;
        if (!sessionStorage.getItem('pwa-dismissed')) setTimeout(() => _banner.style.display = 'block', 4000);
    });
    document.getElementById('pwa-install-btn')?.addEventListener('click', async () => {
        _banner.style.display = 'none';
        if (_pwaPrompt) { _pwaPrompt.prompt(); const {outcome} = await _pwaPrompt.userChoice; _pwaPrompt = null; if(outcome==='accepted') pwaToast('✅ ¡GestiónAula instalada!','bg-success'); }
    });
    document.getElementById('pwa-dismiss-btn')?.addEventListener('click', () => {
        _banner.style.display = 'none'; sessionStorage.setItem('pwa-dismissed','1');
    });
    window.addEventListener('appinstalled', () => { _banner.style.display = 'none'; _pwaPrompt = null; });

    // ── Badges de estado en navbar ──────────────────────────────────
    function actualizarBadgeConexion(online) {
        const badge  = document.getElementById('badge-conexion');
        const texto  = document.getElementById('badge-conexion-texto');
        const dot    = document.getElementById('badge-conexion-dot');
        if (!badge) return;
        if (online) {
            badge.style.background = '#198754'; // verde
            texto.textContent      = 'Conectado';
            dot.style.animation    = 'none';
        } else {
            badge.style.background = '#dc3545'; // rojo
            texto.textContent      = 'Sin conexión';
            dot.style.animation    = 'pulse-dot 1.2s ease-in-out infinite';
        }
    }

    function actualizarBadgeSync(estado, pendientes) {
        const badge = document.getElementById('badge-sync');
        const icono = document.getElementById('badge-sync-icono');
        const texto = document.getElementById('badge-sync-texto');
        if (!badge) return;

        if (estado === 'ok') {
            badge.style.background = '#198754'; // verde
            icono.className        = 'bi bi-check-circle-fill';
            icono.style.animation  = 'none';
            texto.textContent      = 'Sincronizado';
            badge.title            = 'Todos los datos están sincronizados';
        } else if (estado === 'sincronizando') {
            badge.style.background = '#ffc107'; // amarillo
            badge.style.color      = '#212529';
            icono.className        = 'bi bi-arrow-repeat';
            icono.style.animation  = 'spin 1s linear infinite';
            texto.textContent      = 'Sincronizando...';
            badge.title            = 'Sincronizando datos con el servidor';
        } else {
            badge.style.background = '#dc3545'; // rojo
            badge.style.color      = 'white';
            icono.className        = 'bi bi-exclamation-circle-fill';
            icono.style.animation  = 'none';
            texto.textContent      = `${pendientes} sin sync`;
            badge.title            = `${pendientes} registro${pendientes > 1 ? 's' : ''} pendiente${pendientes > 1 ? 's' : ''} — Click para sincronizar`;
        }
    }

    // Estado inicial
    actualizarBadgeConexion(navigator.onLine);

    // Cuando cambia la conexión
    window.addEventListener('online',  () => actualizarBadgeConexion(true));
    window.addEventListener('offline', () => {
        actualizarBadgeConexion(false);
        actualizarBadgeSync('pendiente', '?');
    });

    // Escuchar eventos del OfflineManager
    window.addEventListener('gestionaula:sync:inicio', () => {
        actualizarBadgeSync('sincronizando', 0);
    });
    window.addEventListener('gestionaula:sync:fin', (e) => {
        const p = e.detail?.pendientes ?? 0;
        actualizarBadgeSync(p > 0 ? 'pendiente' : 'ok', p);
    });
    window.addEventListener('gestionaula:sync:nada', () => {
        actualizarBadgeSync('ok', 0);
    });

    // Revisar pendientes al cargar (cuando OfflineManager esté listo)
    window.addEventListener('DOMContentLoaded', () => {
        setTimeout(async () => {
            if (typeof OfflineManager !== 'undefined') {
                const n = await OfflineManager.contarPendientes();
                actualizarBadgeSync(n > 0 ? 'pendiente' : 'ok', n);
            }
        }, 1500);
    });

    function pwaToast(msg, cls='bg-primary') {
        let tc = document.getElementById('_pwa_toasts');
        if (!tc) { tc = document.createElement('div'); tc.id='_pwa_toasts'; tc.style.cssText='position:fixed;bottom:80px;right:20px;z-index:99999;min-width:260px'; document.body.appendChild(tc); }
        const t = document.createElement('div');
        t.className = `toast align-items-center text-white border-0 ${cls} show mb-2`;
        t.innerHTML = `<div class="d-flex"><div class="toast-body fw-semibold">${msg}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" onclick="this.closest('.toast').remove()"></button></div>`;
        tc.appendChild(t); setTimeout(() => t.remove?.(), 6000);
    }
    </script>
</body>

</html>
<?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/layouts/app.blade.php ENDPATH**/ ?>