<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-plus-circle me-2"></i>Agregar horario</h4>
    </div>
    <div class="col-auto">
        <a href="<?php echo e(route('horarios.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white fw-semibold">
        <i class="bi bi-file-earmark-person me-1 text-primary"></i>
        Cargar desde una designación
        <span class="badge bg-info ms-2">Opcional</span>
    </div>
    <div class="card-body">
        <p class="text-muted small mb-3">
            Seleccioná una designación para completar automáticamente los datos del horario.
        </p>
        <div class="row g-3">
            <div class="col-md-8">
                <select id="selectDesignacion" class="form-select">
                    <option value="">— Seleccioná una designación para autocompletar —</option>
                    <?php $__currentLoopData = $designacionesFilas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($i); ?>"
                            data-nombreestablecimiento="<?php echo e($f['nombreestablecimiento']); ?>"
                            data-numeroescuela="<?php echo e($f['numeroescuela'] ?? ''); ?>"
                            data-nombremateria="<?php echo e($f['nombremateria']); ?>"
                            data-anodesignado="<?php echo e($f['anodesignado']); ?>"
                            data-divisiondesignada="<?php echo e($f['divisiondesignada']); ?>"
                            data-turno="<?php echo e($f['turno']); ?>"
                            data-dia="<?php echo e($f['dia']); ?>"
                            data-horaentrada="<?php echo e($f['horaentrada']); ?>"
                            data-horasalida="<?php echo e($f['horasalida']); ?>">
                            <?php echo e($f['nombreestablecimiento']); ?> — <?php echo e($f['nombremateria']); ?>

                            (<?php echo e(\App\Models\Designacion::DIAS[$f['dia']] ?? $f['dia']); ?>

                            <?php echo e($f['horaentrada']); ?>-<?php echo e($f['horasalida']); ?>)
                            — <?php echo e($f['anodesignado']); ?>° <?php echo e($f['divisiondesignada']); ?> <?php echo e($f['turno']); ?>

                            <?php if($f['tipohorario'] === 'dividido'): ?>
                                · dividido
                            <?php endif; ?>
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4 d-flex align-items-end">
                <button type="button" class="btn btn-outline-primary w-100" onclick="autocompletar()">
                    <i class="bi bi-magic me-1"></i>Autocompletar campos
                </button>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('horarios.store')); ?>">
            <?php echo csrf_field(); ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger mb-3">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="row g-3">

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Establecimiento</label>
                    <select name="establecimiento_id" id="establecimiento_id" class="form-select">
                        <option value="">— Sin establecimiento —</option>
                        <?php $__currentLoopData = $establecimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $est): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($est->id); ?>"
                                data-nombre="<?php echo e(strtolower($est->nombre)); ?>"
                                <?php echo e(old('establecimiento_id') == $est->id ? 'selected' : ''); ?>>
                                <?php echo e($est->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div id="hintEstablecimiento" class="form-text text-warning d-none">
                        <i class="bi bi-exclamation-triangle me-1"></i>
                        El establecimiento de la designación no coincide exactamente.
                        Seleccionalo manualmente.
                    </div>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Curso <span class="text-danger">*</span></label>
                    <select name="curso_id" id="curso_id"
                            class="form-select <?php $__errorArgs = ['curso_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">— Seleccioná un curso —</option>
                        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($curso->id); ?>"
                                data-anio="<?php echo e(strtolower($curso->anio)); ?>"
                                data-division="<?php echo e(strtolower($curso->division)); ?>"
                                data-turno="<?php echo e(strtolower($curso->turno)); ?>"
                                <?php echo e(old('curso_id') == $curso->id ? 'selected' : ''); ?>>
                                <?php echo e($curso->nombre_completo); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['curso_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Materia</label>
                    <select name="materia_id" id="materia_id" class="form-select">
                        <option value="">— Sin materia —</option>
                        <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>"
                                data-nombre="<?php echo e(strtolower($m->nombre)); ?>"
                                <?php echo e(old('materia_id') == $m->id ? 'selected' : ''); ?>>
                                <?php echo e($m->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div id="hintMateria" class="form-text text-warning d-none">
                        <i class="bi bi-exclamation-triangle me-1"></i>
                        La materia de la designación no coincide exactamente.
                        Seleccionala manualmente.
                    </div>
                </div>

                
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Día <span class="text-danger">*</span></label>
                    <select name="dia" id="dia"
                            class="form-select <?php $__errorArgs = ['dia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">—</option>
                        <?php $__currentLoopData = $dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dia); ?>" <?php echo e(old('dia') == $dia ? 'selected' : ''); ?>>
                                <?php echo e(ucfirst($dia)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['dia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Hora inicio <span class="text-danger">*</span></label>
                    <input type="time" name="horainicio" id="horainicio"
                           class="form-control <?php $__errorArgs = ['horainicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('horainicio')); ?>" required>
                    <?php $__errorArgs = ['horainicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Hora fin <span class="text-danger">*</span></label>
                    <input type="time" name="horafin" id="horafin"
                           class="form-control <?php $__errorArgs = ['horafin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('horafin')); ?>" required>
                    <?php $__errorArgs = ['horafin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-circle me-1"></i>Guardar horario
                </button>
                <a href="<?php echo e(route('horarios.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
const materiasPorCurso = <?php echo json_encode($cursos->mapWithKeys(function($c) use ($materias) {
    $delCurso = $materias->filter(function($m) use ($c) {
        return $m->anio == $c->anio
            && (empty($c->especialidad_id) || $m->especialidad_id == $c->especialidad_id)
            && (empty($c->establecimiento_id) || $m->establecimiento_id == $c->establecimiento_id);
    })->values();

    return [$c->id => $delCurso->map(fn($m) => ['id' => $m->id, 'nombre' => $m->nombre])];
}), 512) ?>;
const todasLasMaterias = <?php echo json_encode($materias->map(fn($m) => ['id' => $m->id, 'nombre' => $m->nombre]), 512) ?>;

document.getElementById('curso_id').addEventListener('change', function () {
    const select  = document.getElementById('materia_id');
    const cursoId = this.value;
    const materias = (cursoId && materiasPorCurso[cursoId]?.length)
                   ? materiasPorCurso[cursoId]
                   : todasLasMaterias;

    select.innerHTML = '<option value="">— Sin materia —</option>';
    materias.forEach(m => {
        select.innerHTML += `<option value="${m.id}" data-nombre="${m.nombre.toLowerCase()}">${m.nombre}</option>`;
    });
});

function autocompletar() {
    const sel = document.getElementById('selectDesignacion');
    const opt = sel.options[sel.selectedIndex];

    if (!opt || !opt.value) {
        alert('Seleccioná una designación primero.');
        return;
    }

    const nombreEstab   = opt.dataset.nombreestablecimiento?.toLowerCase() ?? '';
    const nombreMateria = opt.dataset.nombremateria?.toLowerCase() ?? '';
    const anoDesignado  = opt.dataset.anodesignado?.toLowerCase() ?? '';
    const division      = opt.dataset.divisiondesignada?.toLowerCase() ?? '';
    const turno         = opt.dataset.turno?.toLowerCase() ?? '';
    const dia           = opt.dataset.dia ?? '';
    const horaEntrada   = opt.dataset.horaentrada ?? '';
    const horaSalida    = opt.dataset.horasalida ?? '';

    // Día
    document.getElementById('dia').value = dia;

    // Horas
    document.getElementById('horainicio').value = horaEntrada;
    document.getElementById('horafin').value     = horaSalida;

    // Establecimiento — buscar por nombre similar
    let estEncontrado = false;
    const selectEst = document.getElementById('establecimiento_id');
    for (let i = 0; i < selectEst.options.length; i++) {
        const opt = selectEst.options[i];
        const nombre = opt.dataset.nombre ?? '';
        if (nombre && (
            nombre.includes(nombreEstab) ||
            nombreEstab.includes(nombre) ||
            levenshtein(nombre, nombreEstab) < 5
        )) {
            selectEst.value = opt.value;
            estEncontrado = true;
            break;
        }
    }
    document.getElementById('hintEstablecimiento').classList.toggle('d-none', estEncontrado);

    // Curso — buscar por año, división y turno
    let cursoEncontrado = false;
    const selectCurso = document.getElementById('curso_id');
    for (let i = 0; i < selectCurso.options.length; i++) {
        const opt   = selectCurso.options[i];
        const anio  = opt.dataset.anio ?? '';
        const div   = opt.dataset.division ?? '';
        const trn   = opt.dataset.turno ?? '';
        if (
            anio.includes(anoDesignado) || anoDesignado.includes(anio)
        ) {
            if (div === division || !division) {
                if (trn.includes(turno) || turno.includes(trn) || !turno) {
                    selectCurso.value = opt.value;
                    cursoEncontrado = true;
                    // Actualizar materias del curso
                    selectCurso.dispatchEvent(new Event('change'));
                    break;
                }
            }
        }
    }

    // Materia — buscar por nombre similar (después de actualizar el select)
    setTimeout(() => {
        let materiaEncontrada = false;
        const selectMat = document.getElementById('materia_id');
        for (let i = 0; i < selectMat.options.length; i++) {
            const opt    = selectMat.options[i];
            const nombre = opt.dataset.nombre ?? '';
            if (nombre && (
                nombre.includes(nombreMateria) ||
                nombreMateria.includes(nombre) ||
                levenshtein(nombre, nombreMateria) < 8
            )) {
                selectMat.value = opt.value;
                materiaEncontrada = true;
                break;
            }
        }
        document.getElementById('hintMateria').classList.toggle('d-none', materiaEncontrada);
    }, 300);

    // Feedback visual
    const btn = event.target;
    const original = btn.innerHTML;
    btn.innerHTML = '<i class="bi bi-check-circle me-1"></i>Completado';
    btn.classList.replace('btn-outline-primary', 'btn-success');
    setTimeout(() => {
        btn.innerHTML = original;
        btn.classList.replace('btn-success', 'btn-outline-primary');
    }, 2000);
}

// Distancia Levenshtein para matching aproximado
function levenshtein(a, b) {
    const m = a.length, n = b.length;
    const dp = Array.from({length: m+1}, (_, i) => Array.from({length: n+1}, (_, j) => i === 0 ? j : j === 0 ? i : 0));
    for (let i = 1; i <= m; i++) {
        for (let j = 1; j <= n; j++) {
            dp[i][j] = a[i-1] === b[j-1]
                ? dp[i-1][j-1]
                : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]);
        }
    }
    return dp[m][n];
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/horarios/create.blade.php ENDPATH**/ ?>