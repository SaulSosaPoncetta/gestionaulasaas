<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-journal-text me-2"></i>Calificar actividades</h4>
        <p class="text-muted">Seleccioná la materia y el curso para continuar.</p>
        <?php if($materiaActiva): ?>
        <span class="badge bg-success mt-1">
            <i class="bi bi-play-circle me-1"></i>Clase activa detectada — materia y curso preseleccionados
        </span>
        <?php endif; ?>
    </div>
    <div class="col-auto">
        <a href="<?php echo e(route('calificaciones.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('calificaractividad.ver')); ?>">
            <div class="row g-3">

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        <span class="badge bg-primary me-1">1</span>Materia
                    </label>
                    <select name="materia_id" id="materia_id" class="form-select" required>
                        <option value="">Seleccioná una materia...</option>
                        <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>"
                                <?php echo e($materiaId == $m->id ? 'selected' : ''); ?>>
                                <?php echo e($m->nombre); ?><?php echo e($materiaActiva == $m->id ? ' ⚡' : ''); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        <span class="badge bg-primary me-1">2</span>Curso
                    </label>
                    <select name="curso_id" id="curso_id" class="form-select" required
                            <?php echo e($cursos->isEmpty() ? 'disabled' : ''); ?>>
                        <option value="">
                            <?php echo e($cursos->isEmpty() ? 'Seleccioná primero una materia' : 'Seleccioná un curso...'); ?>

                        </option>
                        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>"
                                <?php echo e($cursoActivo == $c->id ? 'selected' : ''); ?>>
                                <?php echo e($c->nombre_completo); ?><?php echo e($cursoActivo == $c->id ? ' ⚡' : ''); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary"
                        <?php echo e($cursos->isEmpty() ? 'disabled' : ''); ?>>
                    <i class="bi bi-arrow-right-circle me-1"></i>Siguiente
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.getElementById('materia_id').addEventListener('change', function () {
    const materiaId = this.value;
    const cursoEl   = document.getElementById('curso_id');

    if (!materiaId) {
        cursoEl.innerHTML = '<option value="">Seleccioná primero una materia</option>';
        cursoEl.disabled  = true;
        return;
    }

    cursoEl.innerHTML = '<option value="">Cargando cursos...</option>';
    cursoEl.disabled  = true;

    fetch(`/api/materias/${materiaId}/cursos`)
        .then(r => r.json())
        .then(cursos => {
            cursoEl.innerHTML = '<option value="">Seleccioná un curso...</option>';
            cursos.forEach(c => {
                const sel   = c.activo ? ' selected' : '';
                const label = c.activo ? `${c.nombre} ⚡` : c.nombre;
                cursoEl.innerHTML += `<option value="${c.id}"${sel}>${label}</option>`;
            });
            cursoEl.disabled = cursos.length === 0;
            if (cursos.length === 1) cursoEl.value = cursos[0].id;
        })
        .catch(() => {
            cursoEl.innerHTML = '<option value="">Error al cargar</option>';
            cursoEl.disabled  = false;
        });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/calificaractividad/index.blade.php ENDPATH**/ ?>