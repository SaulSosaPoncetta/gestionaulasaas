<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-journal-bookmark me-2"></i>Planificaciones</h4>
        <p class="text-muted">Planificación anual por materia.</p>
    </div>
    <div class="col-auto">
        <a href="<?php echo e(route('planificaciones.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle me-1"></i>Nueva planificación
        </a>
    </div>
</div>

<?php if($planificaciones->isEmpty()): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>No hay planificaciones registradas.
    </div>
<?php else: ?>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th class="ps-4">Materia</th>
                    <th>Ciclo lectivo</th>
                    <th>Descripción</th>
                    <th class="text-center">Unidades</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $planificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="ps-4 fw-semibold"><?php echo e($plan->materia?->nombre ?? '—'); ?></td>
                    <td><?php echo e($plan->ciclo); ?></td>
                    <td class="text-muted small"><?php echo e(Str::limit($plan->descripcion, 60) ?? '—'); ?></td>
                    <td class="text-center">
                        <span class="badge bg-primary"><?php echo e($plan->unidades_count); ?></span>
                    </td>
                    <td class="text-end pe-3">
                        <a href="<?php echo e(route('planificaciones.show', $plan)); ?>"
                           class="btn btn-sm btn-outline-primary me-1">
                            <i class="bi bi-eye"></i>
                        </a>
                        <a href="<?php echo e(route('planificaciones.edit', $plan)); ?>"
                           class="btn btn-sm btn-outline-secondary me-1">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <form method="POST" action="<?php echo e(route('planificaciones.destroy', $plan)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger"
                                    onclick="return confirm('¿Eliminar esta planificación y todas sus unidades?')">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($planificaciones->links()); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/planificaciones/index.blade.php ENDPATH**/ ?>