<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-clipboard2-arrow me-2"></i>Actividades asignadas</h4>
        <p class="text-muted">
            <strong><?php echo e($materia->nombre); ?></strong>
            &mdash;
            <strong><?php echo e($curso->nombre_completo); ?></strong>
        </p>
    </div>
    <div class="col-auto d-flex gap-2">
        <a href="<?php echo e(route('asignarnuevo.index')); ?>" class="btn btn-outline-primary">
            <i class="bi bi-plus-circle me-1"></i>Asignar nueva actividad
        </a>
        <a href="<?php echo e(route('asignaractividad.seleccionar')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<div class="row g-4">

    
    <div class="col-md-7">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white fw-semibold">
                <i class="bi bi-clipboard2-check me-1"></i>
                Actividades asignadas (<?php echo e($asignaciones->count()); ?>)
            </div>
            <div class="card-body p-0">
                <?php if($asignaciones->isEmpty()): ?>
                    <div class="p-4 text-center text-muted">
                        <i class="bi bi-clipboard2 fs-2 d-block mb-2"></i>
                        No hay actividades asignadas para esta materia y curso.
                    </div>
                <?php else: ?>
                <div class="list-group list-group-flush">
                    <?php $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group-item px-4 py-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="flex-grow-1">

                                
                                <div class="fw-semibold fs-6 mb-1">
                                    <?php echo e($asig->actividad?->tema ?? '—'); ?>

                                </div>

                                <div class="d-flex flex-wrap gap-1 mb-2">
                                    <?php if($asig->actividad?->numerounidad): ?>
                                        <span class="badge bg-secondary">
                                            Unidad <?php echo e($asig->actividad->numerounidad); ?>

                                        </span>
                                    <?php endif; ?>
                                    <?php if($asig->actividad?->numeroactividad): ?>
                                        <span class="badge bg-secondary">
                                            Act. N° <?php echo e($asig->actividad->numeroactividad); ?>

                                        </span>
                                    <?php endif; ?>
                                    <?php if($asig->actividad?->tipoactividad): ?>
                                        <span class="badge bg-info">
                                            <?php echo e($asig->actividad->tipoactividad->denominacion); ?>

                                        </span>
                                    <?php endif; ?>
                                    <?php if($asig->esgrupal): ?>
                                        <span class="badge bg-warning text-dark">
                                            Grupal (<?php echo e($asig->integrantesporgrupo); ?> por grupo)
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-dark">Individual</span>
                                    <?php endif; ?>

                                    
                                    <span class="badge bg-<?php echo e($asig->estado === 'activa' ? 'success' : 'secondary'); ?>">
                                        <?php echo e(ucfirst($asig->estado)); ?>

                                    </span>

                                    
                                    <?php if(($asig->conteo_enproceso ?? 0) > 0): ?>
                                    <span class="badge bg-primary" title="Alumnos en proceso">
                                        <i class="bi bi-hourglass-split me-1"></i>En proceso: <?php echo e($asig->conteo_enproceso ?? 0); ?>

                                    </span>
                                    <?php endif; ?>

                                    <?php if(($asig->conteo_atiempo ?? 0) > 0): ?>
                                    <span class="badge bg-success" title="Entregado a tiempo">
                                        <i class="bi bi-check-circle me-1"></i>A tiempo: <?php echo e($asig->conteo_atiempo ?? 0); ?>

                                    </span>
                                    <?php endif; ?>

                                    <?php if(($asig->conteo_vencido_entregado ?? 0) > 0): ?>
                                    <span class="badge bg-warning text-dark" title="Entregado fuera de fecha">
                                        <i class="bi bi-clock-history me-1"></i>Entregado vencido: <?php echo e($asig->conteo_vencido_entregado ?? 0); ?>

                                    </span>
                                    <?php endif; ?>

                                    <?php if(($asig->conteo_vencida ?? 0) > 0): ?>
                                    <span class="badge bg-danger" title="Sin entregar y vencida">
                                        <i class="bi bi-x-circle me-1"></i>Vencidos: <?php echo e($asig->conteo_vencida ?? 0); ?>

                                    </span>
                                    <?php endif; ?>

                                    <?php if(($asig->conteo_incompleta ?? 0) > 0): ?>
                                    <span class="badge bg-secondary" title="Entrega incompleta">
                                        <i class="bi bi-dash-circle me-1"></i>Incompletos: <?php echo e($asig->conteo_incompleta ?? 0); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>

                                
                                <?php if($asig->actividad?->subtema): ?>
                                    <div class="text-muted small mb-1">
                                        <i class="bi bi-bookmark me-1"></i><?php echo e($asig->actividad->subtema); ?>

                                    </div>
                                <?php endif; ?>

                                
                                <div class="text-muted small mb-1">
                                    <i class="bi bi-calendar me-1"></i>
                                    Inicio: <?php echo e($asig->fechainicio->format('d/m/Y')); ?>

                                    &mdash;
                                    Entrega: <?php echo e($asig->fechaentrega->format('d/m/Y')); ?>

                                </div>

                                
                                <div class="text-muted small">
                                    <i class="bi bi-list-ol me-1"></i>
                                    <?php echo e($asig->actividad?->items->count() ?? 0); ?> consigna(s)
                                </div>

                            </div>

                            
                            <a href="<?php echo e(route('asignaractividad.detalle', $asig)); ?>"
                               class="btn btn-sm btn-outline-primary ms-3">
                                <i class="bi bi-eye me-1"></i>Ver
                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="col-md-5">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white fw-semibold d-flex justify-content-between align-items-center">
                <span>
                    <i class="bi bi-file-earmark-pdf me-1"></i>
                    Material teórico (<?php echo e($materialteoricoarchivos->count()); ?>)
                </span>
                <a href="<?php echo e(route('materialteoricoarchivos.create')); ?>"
                   class="btn btn-sm btn-outline-danger">
                    <i class="bi bi-plus-circle me-1"></i>Subir
                </a>
            </div>
            <div class="card-body p-0">
                <?php if($materialteoricoarchivos->isEmpty()): ?>
                    <div class="p-4 text-center text-muted">
                        <i class="bi bi-file-earmark-pdf fs-2 d-block mb-2"></i>
                        No hay material teórico cargado para este curso.
                    </div>
                <?php else: ?>
                <div class="list-group list-group-flush">
                    <?php $__currentLoopData = $materialteoricoarchivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group-item px-4 py-3">
                        <div class="fw-semibold mb-1"><?php echo e($arch->titulo); ?></div>
                        <?php if($arch->descripcion): ?>
                            <div class="text-muted small mb-1"><?php echo e($arch->descripcion); ?></div>
                        <?php endif; ?>
                        <?php if($arch->tarea): ?>
                            <div class="text-muted small mb-1">
                                <i class="bi bi-link me-1"></i>
                                Práctico: <?php echo e($arch->tarea->titulo); ?>

                            </div>
                        <?php endif; ?>
                        <div class="text-muted small mb-2">
                            <i class="bi bi-calendar me-1"></i>
                            <?php echo e($arch->created_at->format('d/m/Y')); ?>

                        </div>
                        <div class="d-flex gap-2">
                            <a href="<?php echo e(asset('storage/' . $arch->ruta)); ?>"
                               target="_blank"
                               class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-file-pdf me-1"></i>Ver PDF
                            </a>
                            <button type="button"
                                    class="btn btn-sm btn-outline-primary"
                                    data-bs-toggle="modal"
                                    data-bs-target="#modalAsignar<?php echo e($arch->id); ?>">
                                <i class="bi bi-send me-1"></i>Asignar
                            </button>
                        </div>

                        
                        <div class="modal fade" id="modalAsignar<?php echo e($arch->id); ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h6 class="modal-title fw-bold">
                                            <i class="bi bi-send me-1"></i>Asignar material a práctico
                                        </h6>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p class="text-muted small mb-3">
                                            Seleccioná la actividad a la que querés asignar
                                            <strong><?php echo e($arch->titulo); ?></strong>:
                                        </p>
                                        <form method="POST"
                                              action="<?php echo e(route('materialteoricoarchivos.asignar', $arch)); ?>">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                            <select name="tarea_id" class="form-select mb-3" required>
                                                <option value="">— Seleccioná una actividad —</option>
                                                <?php $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($asig->actividad_id); ?>">
                                                        <?php echo e($asig->actividad?->tema ?? '—'); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="d-flex gap-2">
                                                <button type="submit" class="btn btn-primary btn-sm">
                                                    <i class="bi bi-check-circle me-1"></i>Asignar
                                                </button>
                                                <button type="button"
                                                        class="btn btn-outline-secondary btn-sm"
                                                        data-bs-dismiss="modal">Cancelar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/asignaractividad/ver.blade.php ENDPATH**/ ?>