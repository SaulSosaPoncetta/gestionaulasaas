<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-calendar3 me-2"></i>Horarios</h4>
        <p class="text-muted">Planificacion semanal de clases.</p>
    </div>
    <div class="col-auto">
        <a href="<?php echo e(route('horarios.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle me-1"></i>Agregar horario
        </a>
    </div>
</div>

<?php if($horarios->isEmpty()): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>No hay horarios cargados todavia.
    </div>
<?php else: ?>
<div class="row g-3">
    <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia => $horariosDelDia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-primary text-white fw-semibold">
                    <i class="bi bi-calendar-day me-1"></i><?php echo e(ucfirst($dia)); ?>

                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $horariosDelDia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-start gap-2">
                            <div>
                                <div class="fw-semibold">
                                    <?php echo e($horario->curso?->nombre_completo ?? '-'); ?>

                                </div>
                                <div class="text-muted small">
                                    <?php echo e($horario->materia?->nombre ?? 'Sin materia'); ?>

                                </div>
                                <?php if($horario->establecimiento): ?>
                                <div class="text-muted small">
                                    <i class="bi bi-building me-1"></i><?php echo e($horario->establecimiento->nombre); ?>

                                </div>
                                <?php endif; ?>
                                <div class="text-muted small">
                                    <i class="bi bi-clock me-1"></i>
                                    <?php echo e(\Carbon\Carbon::parse($horario->horainicio)->format('H:i')); ?>

                                    -
                                    <?php echo e(\Carbon\Carbon::parse($horario->horafin)->format('H:i')); ?>

                                </div>
                            </div>
                            <form method="POST" action="<?php echo e(route('horarios.destroy', $horario)); ?>">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger"
                                        onclick="return confirm('Eliminar este horario?')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/horarios/index.blade.php ENDPATH**/ ?>