<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-person-check me-2"></i>Registrar asistencia</h4>
        <p class="text-muted">
            <strong><?php echo e($curso->nombre_completo); ?></strong>
            <?php if($materia): ?> — <?php echo e($materia->nombre); ?> <?php endif; ?>
            &mdash; <?php echo e(\Carbon\Carbon::parse($fecha)->format('d/m/Y')); ?>

        </p>
    </div>
    <div class="col-auto">
        <a href="<?php echo e(route('asistencia.accion', ['curso_id' => $curso->id, 'materia_id' => $materia?->id])); ?>"
           class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<?php if($curso->alumnos->isEmpty()): ?>
    <div class="alert alert-warning">
        <i class="bi bi-exclamation-triangle me-2"></i>Este curso no tiene alumnos registrados.
    </div>
<?php else: ?>


<?php
    $presentesHoy    = $asistencias->where('estado', 'presente')->count();
    $ausentesHoy     = $asistencias->where('estado', 'ausente')->count();
    $justificadosHoy = $asistencias->where('estado', 'justificado')->count();
    $tardeHoy        = $asistencias->where('estado', 'tarde')->count();
    $totalAlumnos    = $curso->alumnos->count();
?>

<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-success"><?php echo e($presentesHoy); ?></div>
                <div class="text-muted small">Presentes hoy</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-danger"><?php echo e($ausentesHoy); ?></div>
                <div class="text-muted small">Ausentes hoy</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-info"><?php echo e($justificadosHoy); ?></div>
                <div class="text-muted small">Justificados hoy</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-warning"><?php echo e($tardeHoy); ?></div>
                <div class="text-muted small">Tarde hoy</div>
            </div>
        </div>
    </div>
</div>

<form method="POST" action="<?php echo e(route('asistencia.guardar')); ?>" enctype="multipart/form-data" id="form-asistencia">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="curso_id"   value="<?php echo e($curso->id); ?>">
    <input type="hidden" name="materia_id" value="<?php echo e($materia?->id); ?>">
    <input type="hidden" name="fecha"      value="<?php echo e($fecha); ?>">

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover mb-0 align-middle" id="tablaasistencia">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4" style="min-width:180px">Alumno</th>
                        <th class="text-center"><span class="badge bg-success">Presente</span></th>
                        <th class="text-center"><span class="badge bg-danger">Ausente</span></th>
                        <th class="text-center"><span class="badge bg-warning text-dark">Tarde</span></th>
                        <th style="min-width:160px">Hora llegada</th>
                        <th style="min-width:200px">Justificación (foto)</th>
                        <th style="min-width:160px">Observación</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $curso->alumnos->sortBy('apellido'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $reg          = $asistencias[$alumno->id] ?? null;
                        $estadoActual = $reg?->estado ?? 'presente';
                    ?>
                    <tr class="fila-alumno" data-alumno="<?php echo e($alumno->id); ?>">
                        <td class="ps-4 fw-semibold"><?php echo e($alumno->nombre_completo); ?></td>

                        <td class="text-center">
                            <input class="form-check-input radio-estado fs-5" type="radio"
                                   name="asistencias[<?php echo e($alumno->id); ?>][estado]"
                                   value="presente"
                                   <?php echo e($estadoActual === 'presente' ? 'checked' : ''); ?> required>
                        </td>

                        <td class="text-center">
                            <input class="form-check-input radio-estado fs-5" type="radio"
                                   name="asistencias[<?php echo e($alumno->id); ?>][estado]"
                                   value="ausente"
                                   <?php echo e($estadoActual === 'ausente' ? 'checked' : ''); ?>>
                        </td>

                        <td class="text-center">
                            <input class="form-check-input radio-estado fs-5" type="radio"
                                   name="asistencias[<?php echo e($alumno->id); ?>][estado]"
                                   value="tarde"
                                   <?php echo e($estadoActual === 'tarde' ? 'checked' : ''); ?>>
                        </td>

                        <td>
                            <input type="time"
                                   class="form-control form-control-sm campo-hora"
                                   name="asistencias[<?php echo e($alumno->id); ?>][horallegada]"
                                   value="<?php echo e($reg?->horallegada ?? ''); ?>"
                                   <?php echo e($estadoActual !== 'tarde' ? 'style=display:none' : ''); ?>>
                        </td>

                        <td>
                            <div class="campo-foto"
                                 <?php echo e(!in_array($estadoActual, ['ausente','justificado']) ? 'style=display:none' : ''); ?>>
                                <input type="file"
                                       class="form-control form-control-sm"
                                       name="fotos[<?php echo e($alumno->id); ?>]"
                                       accept="image/*,application/pdf">
                                <?php if($reg?->fotojustificacion): ?>
                                    <small class="text-success d-block mt-1">
                                        <i class="bi bi-check-circle me-1"></i>Ya tiene foto
                                    </small>
                                <?php endif; ?>
                            </div>
                        </td>

                        <td>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   name="asistencias[<?php echo e($alumno->id); ?>][observacion]"
                                   value="<?php echo e($reg?->observacion ?? ''); ?>"
                                   placeholder="Opcional">
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-success">
            <i class="bi bi-check-circle me-1"></i>Guardar asistencia
        </button>
        <a href="<?php echo e(route('asistencia.accion', ['curso_id' => $curso->id, 'materia_id' => $materia?->id])); ?>"
           class="btn btn-outline-secondary">Cancelar</a>
    </div>
</form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.fila-alumno').forEach(function (fila) {
        const radios    = fila.querySelectorAll('.radio-estado');
        const campoHora = fila.querySelector('.campo-hora');
        const campoFoto = fila.querySelector('.campo-foto');

        function actualizarCampos(estado) {
            if (estado === 'tarde') {
                campoHora.style.display = '';
                if (!campoHora.value) {
                    const ahora = new Date();
                    const hh = String(ahora.getHours()).padStart(2, '0');
                    const mm = String(ahora.getMinutes()).padStart(2, '0');
                    campoHora.value = `${hh}:${mm}`;
                }
            } else {
                campoHora.style.display = 'none';
                campoHora.value = '';
            }

            if (campoFoto) {
                if (estado === 'ausente') {
                    campoFoto.style.display = '';
                } else {
                    campoFoto.style.display = 'none';
                    const fileInput = campoFoto.querySelector('input[type=file]');
                    if (fileInput) fileInput.value = '';
                }
            }
        }

        const checkedRadio = fila.querySelector('.radio-estado:checked');
        if (checkedRadio) actualizarCampos(checkedRadio.value);

        radios.forEach(function (radio) {
            radio.addEventListener('change', function () {
                actualizarCampos(this.value);
            });
        });
    });
});
</script>

<script>
// ── Soporte offline para asistencia ─────────────────────────────────
document.getElementById('form-asistencia')?.addEventListener('submit', async function(e) {
    if (navigator.onLine) return; // Si hay internet, envío normal al server

    e.preventDefault();

    const form     = e.target;
    const formData = new FormData(form);
    const cursoId  = formData.get('curso_id');
    const materiaId= formData.get('materia_id');
    const fecha    = formData.get('fecha');

    // Recolectar asistencias del formulario
    const ops = [];
    for (const [key, valor] of formData.entries()) {
        const m = key.match(/^asistencias\[(\d+)\]\[estado\]$/);
        if (m) {
            const alumnoId = m[1];
            ops.push(OfflineManager.guardar('asistencias', 'insert', {
                alumno_id:   parseInt(alumnoId),
                curso_id:    parseInt(cursoId),
                materia_id:  parseInt(materiaId),
                fecha:       fecha,
                estado:      valor,
                horallegada: formData.get(`asistencias[${alumnoId}][horallegada]`) || null,
                observacion: formData.get(`asistencias[${alumnoId}][observacion]`) || null,
            }));
        }
    }

    await Promise.all(ops);

    // Mostrar confirmación
    const alerta = document.createElement('div');
    alerta.className = 'alert alert-warning mt-3';
    alerta.innerHTML = '⚠️ <strong>Sin conexión</strong> — Asistencias guardadas localmente. Se sincronizarán automáticamente cuando vuelva internet.';
    form.insertAdjacentElement('afterend', alerta);
    form.querySelector('[type=submit]').disabled = true;
    form.querySelector('[type=submit]').textContent = '✅ Guardado localmente';
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/asistencia/registrar.blade.php ENDPATH**/ ?>