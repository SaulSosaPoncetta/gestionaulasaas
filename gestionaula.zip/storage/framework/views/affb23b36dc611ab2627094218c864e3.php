<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-journal-text me-2"></i>Calificar actividades</h4>
        <p class="text-muted">
            <strong><?php echo e($materia->nombre); ?></strong>
            &mdash;
            <strong><?php echo e($curso->nombre_completo); ?></strong>
        </p>
    </div>
    <div class="col-auto d-flex gap-2">
        <a href="<?php echo e(route('calificaractividad.historial', ['materia_id' => $materia->id, 'curso_id' => $curso->id])); ?>"
           class="btn btn-outline-secondary">
            <i class="bi bi-clock-history me-1"></i>Historial
        </a>
        <a href="<?php echo e(route('calificaractividad.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <i class="bi bi-check-circle me-2"></i><?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if($asignaciones->isEmpty()): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>No hay actividades asignadas para esta materia y curso.
    </div>
<?php elseif($todosAlumnos->isEmpty()): ?>
    <div class="alert alert-warning">
        <i class="bi bi-exclamation-circle me-2"></i>No hay alumnos registrados en este curso.
    </div>
<?php else: ?>


<div class="card border-0 shadow-sm mb-4">
    <div class="card-body py-3">
        <form method="GET" action="<?php echo e(route('calificaractividad.ver')); ?>"
              class="row g-2 align-items-center" id="form-buscar">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="materia_id" value="<?php echo e($materia->id); ?>">
            <input type="hidden" name="curso_id"   value="<?php echo e($curso->id); ?>">
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-text bg-white">
                        <i class="bi bi-search text-muted"></i>
                    </span>
                    <input type="text" name="buscar" id="input-buscar"
                           class="form-control border-start-0"
                           placeholder="Buscar por apellido o nombre..."
                           value="<?php echo e($buscar ?? ''); ?>"
                           autocomplete="off">
                    <?php if($buscar): ?>
                    <a href="<?php echo e(route('calificaractividad.ver', ['materia_id' => $materia->id, 'curso_id' => $curso->id])); ?>"
                       class="btn btn-outline-secondary">
                        <i class="bi bi-x"></i>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-search me-1"></i>Buscar
                </button>
            </div>
            <div class="col-auto ms-auto text-muted small">
                <?php if($buscar): ?>
                    <?php echo e($alumnos->count()); ?> resultado(s) para "<?php echo e($buscar); ?>"
                <?php else: ?>
                    <?php echo e($todosAlumnos->count()); ?> alumno(s) en total
                    &mdash;
                    <button type="button" class="btn btn-link btn-sm p-0 text-primary"
                            onclick="expandirTodos()">Expandir todos</button>
                    /
                    <button type="button" class="btn btn-link btn-sm p-0 text-secondary"
                            onclick="colapsarTodos()">Colapsar todos</button>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>


<?php if($alumnos->isEmpty()): ?>
<div class="alert alert-warning">
    <i class="bi bi-person-x me-2"></i>No se encontraron alumnos con "<?php echo e($buscar); ?>".
</div>
<?php endif; ?>


<div class="accordion" id="acordeonAlumnos">

<?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumnoIdx => $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $acId         = 'alumno_' . $alumno->id;
    $primerAlumno = $alumnoIdx === 0;
?>

<div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden alumno-item"
     data-nombre="<?php echo e(strtolower($alumno->apellido . ' ' . $alumno->nombre)); ?>">

    
    <h2 class="accordion-header" id="header_<?php echo e($acId); ?>">
        <button class="accordion-button <?php echo e($primerAlumno ? '' : 'collapsed'); ?> fw-semibold"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapse_<?php echo e($acId); ?>"
                aria-expanded="<?php echo e($primerAlumno ? 'true' : 'false'); ?>"
                aria-controls="collapse_<?php echo e($acId); ?>"
                style="background: #f8f9fa">
            <div class="d-flex align-items-center gap-3 w-100 me-3">
                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                     style="width:36px;height:36px;font-size:13px;font-weight:700">
                    <?php echo e(strtoupper(substr($alumno->apellido, 0, 1))); ?>

                </div>
                <div class="flex-grow-1">
                    <span class="fs-6"><?php echo e($alumno->apellido); ?>, <?php echo e($alumno->nombre); ?></span>
                    <?php if($alumno->tipocursada === 'libre'): ?>
                        <span class="badge bg-warning text-dark ms-2 small">Libre</span>
                    <?php endif; ?>
                </div>
                <?php
                    $notasAlumno   = $notasRegistradas->filter(fn($n) => $n->alumno_id === $alumno->id);
                    $totalActs     = $asignaciones->count();
                    $calificadas   = $notasAlumno->count();
                    $porcentaje    = $totalActs > 0 ? intval($calificadas / $totalActs * 100) : 0;
                    $colorBarra    = $porcentaje === 100 ? 'success' : ($porcentaje >= 50 ? 'warning' : 'danger');
                ?>
                <div class="d-flex align-items-center gap-2 me-3">
                    <small class="text-muted"><?php echo e($calificadas); ?>/<?php echo e($totalActs); ?> calificadas</small>
                    <div class="progress flex-shrink-0" style="width:80px;height:6px">
                        <div class="progress-bar bg-<?php echo e($colorBarra); ?>" style="width:<?php echo e($porcentaje); ?>%"></div>
                    </div>
                    <?php if($calificadas === $totalActs && $totalActs > 0): ?>
                        <span class="badge bg-success"><i class="bi bi-check-all"></i></span>
                    <?php endif; ?>
                </div>
            </div>
        </button>
    </h2>

    
    <div id="collapse_<?php echo e($acId); ?>"
         class="accordion-collapse collapse <?php echo e($primerAlumno ? 'show' : ''); ?>"
         aria-labelledby="header_<?php echo e($acId); ?>"
         data-bs-parent="">
        <div class="accordion-body p-0">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Actividad</th>
                        <th>Tipo</th>
                        <th>Entrega</th>
                        <th class="text-center">Estado</th>
                        <th class="text-center">Nota individual</th>
                        <th class="text-center">Nota grupal</th>
                        <th class="text-center">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $key  = $alumno->id . '_' . $asig->id;
                        $nota = $notasRegistradas->get($key);

                        $estadoAuto = 'pendiente';
                        if ($nota) {
                            $estadoAuto = $nota->estado;
                        } elseif ($asig->fechaentrega->isPast()) {
                            $estadoAuto = 'vencido';
                        } elseif ($asig->fechainicio->isPast() || $asig->fechainicio->isToday()) {
                            $estadoAuto = 'enproceso';
                        }

                        $grupoAlumno = null;
                        if ($asig->actividad?->esgrupal) {
                            foreach ($asig->actividad->grupos as $grupo) {
                                if ($grupo->alumnos->contains('id', $alumno->id)) {
                                    $grupoAlumno = $grupo;
                                    break;
                                }
                            }
                        }
                    ?>
                    <tr>
                        <td class="ps-4">
                            <div class="fw-semibold"><?php echo e($asig->actividad?->tema ?? '—'); ?></div>
                            <?php if($asig->actividad?->numerounidad): ?>
                                <span class="badge bg-secondary">Unidad <?php echo e($asig->actividad->numerounidad); ?></span>
                            <?php endif; ?>
                            <?php if($asig->actividad?->numeroactividad): ?>
                                <span class="badge bg-secondary">Act. N° <?php echo e($asig->actividad->numeroactividad); ?></span>
                            <?php endif; ?>
                            <?php if($grupoAlumno): ?>
                                <span class="badge bg-info"><?php echo e($grupoAlumno->nombre); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="small"><?php echo e($asig->actividad?->tipoactividad?->denominacion ?? '—'); ?></td>
                        <td class="small"><?php echo e($asig->fechaentrega->format('d/m/Y')); ?></td>
                        <td class="text-center">
                            <?php
                                $badgeEstado = match($estadoAuto) {
                                    'entregado' => 'success',
                                    'vencido'   => 'danger',
                                    'enproceso' => 'primary',
                                    default     => 'secondary',
                                };
                                $labelEstado = match($estadoAuto) {
                                    'entregado' => 'Entregado',
                                    'vencido'   => 'Vencido',
                                    'enproceso' => 'En proceso',
                                    default     => 'Pendiente',
                                };
                            ?>
                            <span class="badge bg-<?php echo e($badgeEstado); ?>"><?php echo e($labelEstado); ?></span>
                        </td>
                        <td class="text-center">
                            <?php if($nota?->notaindividual !== null): ?>
                                <span class="badge bg-<?php echo e($nota->notaindividual >= 7 ? 'success' : ($nota->notaindividual >= 4 ? 'warning' : 'danger')); ?> fs-6">
                                    <?php echo e(number_format($nota->notaindividual, 2)); ?>

                                </span>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if($asig->esgrupal): ?>
                                <?php if($nota?->notagrupal !== null): ?>
                                    <span class="badge bg-<?php echo e($nota->notagrupal >= 7 ? 'success' : ($nota->notagrupal >= 4 ? 'warning' : 'danger')); ?> fs-6">
                                        <?php echo e(number_format($nota->notagrupal, 2)); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-muted small">N/A</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <button type="button" class="btn btn-sm btn-primary"
                                    data-bs-toggle="modal"
                                    data-bs-target="#modalCalificar<?php echo e($alumno->id); ?>_<?php echo e($asig->id); ?>">
                                <i class="bi bi-pencil me-1"></i>Calificar
                            </button>
                        </td>
                    </tr>
                
                <div class="modal fade" id="modalCalificar<?php echo e($alumno->id); ?>_<?php echo e($asig->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h6 class="modal-title fw-bold">
                                    <i class="bi bi-pencil me-1"></i>Calificar actividad
                                </h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <form method="POST" action="<?php echo e(route('calificaractividad.calificar')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="asignacion_id" value="<?php echo e($asig->id); ?>">
                                <input type="hidden" name="alumno_id"     value="<?php echo e($alumno->id); ?>">
                                <input type="hidden" name="actividad_id"  value="<?php echo e($asig->actividad_id); ?>">

                                <div class="modal-body">
                                    <div class="alert alert-light border mb-3">
                                        <div class="fw-semibold"><?php echo e($alumno->nombre_completo); ?></div>
                                        <div class="text-muted small"><?php echo e($asig->actividad?->tema); ?></div>
                                        <?php if($grupoAlumno): ?>
                                            <div class="text-muted small">
                                                <i class="bi bi-people me-1"></i><?php echo e($grupoAlumno->nombre); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label fw-semibold">
                                                Nota individual <span class="text-danger">*</span>
                                            </label>
                                            <input type="number" name="notaindividual"
                                                   class="form-control"
                                                   value="<?php echo e($nota?->notaindividual); ?>"
                                                   min="1" max="10" step="0.25"
                                                   placeholder="1 — 10">
                                        </div>

                                        <?php if($asig->esgrupal): ?>
                                        <div class="col-md-6">
                                            <label class="form-label fw-semibold">
                                                Nota grupal
                                            </label>
                                            <input type="number" name="notagrupal"
                                                   class="form-control"
                                                   value="<?php echo e($nota?->notagrupal); ?>"
                                                   min="1" max="10" step="0.25"
                                                   placeholder="1 — 10">
                                            <div class="form-text">Nota por el trabajo del grupo.</div>
                                        </div>
                                        <?php endif; ?>

                                        <div class="col-12">
                                            <label class="form-label fw-semibold">Estado</label>
                                            <select name="estado" class="form-select">
                                                <option value="pendiente"  <?php echo e(($nota?->estado ?? $estadoAuto) === 'pendiente'  ? 'selected' : ''); ?>>Pendiente</option>
                                                <option value="enproceso"  <?php echo e(($nota?->estado ?? $estadoAuto) === 'enproceso'  ? 'selected' : ''); ?>>En proceso</option>
                                                <option value="entregado"  <?php echo e(($nota?->estado ?? $estadoAuto) === 'entregado'  ? 'selected' : ''); ?>>Entregado</option>
                                                <option value="vencido"    <?php echo e(($nota?->estado ?? $estadoAuto) === 'vencido'    ? 'selected' : ''); ?>>Vencido</option>
                                            </select>
                                        </div>

                                        <div class="col-12">
                                            <label class="form-label fw-semibold">Observación</label>
                                            <textarea name="observacion" class="form-control" rows="2"
                                                      placeholder="Opcional"><?php echo e($nota?->observacion); ?></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-secondary"
                                            data-bs-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-check-circle me-1"></i>Guardar
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Búsqueda en tiempo real (filtra localmente sin recargar)
document.getElementById('input-buscar')?.addEventListener('input', function () {
    const q     = this.value.trim().toLowerCase();
    const items = document.querySelectorAll('.alumno-item');
    let visibles = 0;

    items.forEach(item => {
        const nombre = item.dataset.nombre || '';
        if (!q || nombre.includes(q)) {
            item.style.display = '';
            visibles++;
        } else {
            item.style.display = 'none';
        }
    });
});

// Expandir / colapsar todos
function expandirTodos() {
    document.querySelectorAll('.accordion-collapse').forEach(el => {
        new bootstrap.Collapse(el, { show: true });
    });
}
function colapsarTodos() {
    document.querySelectorAll('.accordion-collapse.show').forEach(el => {
        new bootstrap.Collapse(el, { hide: true });
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/calificaractividad/ver.blade.php ENDPATH**/ ?>