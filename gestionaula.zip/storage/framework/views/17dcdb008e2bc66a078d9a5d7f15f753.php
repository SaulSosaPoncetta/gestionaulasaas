<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h4 class="fw-bold"><i class="bi bi-clipboard2-arrow me-2"></i>Asignar actividad</h4>
        <p class="text-muted">
            <strong><?php echo e($curso->nombre_completo); ?></strong>
            &mdash;
            <strong><?php echo e($materia->nombre); ?></strong>
        </p>
    </div>
    <div class="col-auto">
        <a href="<?php echo e(route('asignarnuevo.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <i class="bi bi-check-circle me-2"></i><?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php if($actividades->isEmpty()): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>No hay actividades cargadas para esta materia.
        <a href="<?php echo e(route('actividades.seleccionar')); ?>" class="alert-link ms-2">Crear una actividad</a>
    </div>
<?php else: ?>
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-semibold">
        <i class="bi bi-list-check me-1"></i>Actividades disponibles (<?php echo e($actividades->count()); ?>)
    </div>
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th class="ps-4">Unidad</th>
                    <th>N° Act.</th>
                    <th>Tema</th>
                    <th>Tipo</th>
                    <th class="text-center">Items</th>
                    <th class="text-center">Estado asig.</th>
                    <th class="text-center">Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $asignada = in_array($act->id, $yaAsignadas); ?>
                <tr>
                    <td class="ps-4 text-center">
                        <span class="badge bg-secondary"><?php echo e($act->numerounidad ?? '—'); ?></span>
                    </td>
                    <td class="text-center"><?php echo e($act->numeroactividad ?? '—'); ?></td>
                    <td class="fw-semibold"><?php echo e($act->tema); ?></td>
                    <td><?php echo e($act->tipoactividad?->denominacion ?? '—'); ?></td>
                    <td class="text-center">
                        <span class="badge bg-info"><?php echo e($act->items->count()); ?></span>
                    </td>
                    <td class="text-center">
                        <?php if($asignada): ?>
                            <span class="badge bg-success">Asignada</span>
                        <?php else: ?>
                            <span class="badge bg-light text-dark">Sin asignar</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <?php if(!$asignada): ?>
                            <button type="button" class="btn btn-sm btn-primary"
                                    data-bs-toggle="modal"
                                    data-bs-target="#modalAsignar<?php echo e($act->id); ?>">
                                <i class="bi bi-send me-1"></i>Asignar
                            </button>
                        <?php else: ?>
                            <span class="text-muted small">Ya asignada</span>
                        <?php endif; ?>
                    </td>
                </tr>

                
                <?php if(!$asignada): ?>
                <div class="modal fade" id="modalAsignar<?php echo e($act->id); ?>" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title fw-bold">
                                    <i class="bi bi-send me-1"></i>Asignar actividad
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <form method="POST" action="<?php echo e(route('asignarnuevo.asignar')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="actividad_id" value="<?php echo e($act->id); ?>">
                                <input type="hidden" name="curso_id"     value="<?php echo e($curso->id); ?>">
                                <input type="hidden" name="materia_id"   value="<?php echo e($materia->id); ?>">

                                <div class="modal-body">
                                    
                                    <div class="alert alert-light border mb-4">
                                        <div class="fw-semibold"><?php echo e($act->tema); ?></div>
                                        <div class="text-muted small">
                                            Unidad <?php echo e($act->numerounidad ?? '—'); ?>

                                            <?php if($act->numeroactividad): ?> | Actividad N° <?php echo e($act->numeroactividad); ?> <?php endif; ?>
                                            | <?php echo e($act->tipoactividad?->denominacion ?? '—'); ?>

                                            | <?php echo e($act->items->count()); ?> consigna(s)
                                        </div>
                                    </div>

                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label fw-semibold">
                                                Fecha inicio <span class="text-danger">*</span>
                                            </label>
                                            <input type="date" name="fechainicio"
                                                   class="form-control"
                                                   value="<?php echo e(date('Y-m-d')); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label fw-semibold">
                                                Fecha entrega <span class="text-danger">*</span>
                                            </label>
                                            <input type="date" name="fechaentrega"
                                                   class="form-control" required>
                                        </div>

                                        
                                        <div class="col-12">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox"
                                                       name="esgrupal" value="1"
                                                       id="esgrupal<?php echo e($act->id); ?>"
                                                       onchange="toggleGrupal(<?php echo e($act->id); ?>)">
                                                <label class="form-check-label fw-semibold"
                                                       for="esgrupal<?php echo e($act->id); ?>">
                                                    Trabajo en grupo
                                                </label>
                                            </div>
                                        </div>

                                        <div id="seccionGrupal<?php echo e($act->id); ?>" style="display:none" class="col-12">
                                            <div class="row g-3">
                                                <div class="col-md-4">
                                                    <label class="form-label fw-semibold">
                                                        Integrantes por grupo
                                                    </label>
                                                    <input type="number" name="integrantesporgrupo"
                                                           class="form-control" min="2" value="2">
                                                </div>
                                                <div class="col-md-8">
                                                    <label class="form-label fw-semibold">Modo</label>
                                                    <div class="d-flex gap-3 mt-2">
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio"
                                                                   name="modogrupo"
                                                                   value="aleatorio" checked>
                                                            <label class="form-check-label">
                                                                <i class="bi bi-shuffle me-1"></i>Aleatorio
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio"
                                                                   name="modogrupo"
                                                                   value="manual">
                                                            <label class="form-check-label">
                                                                <i class="bi bi-hand-index me-1"></i>Manual
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-secondary"
                                            data-bs-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-check-circle me-1"></i>Confirmar asignación
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function toggleGrupal(actId) {
    const chk     = document.getElementById(`esgrupal${actId}`);
    const seccion = document.getElementById(`seccionGrupal${actId}`);
    seccion.style.display = chk.checked ? '' : 'none';
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionaula\resources\views/asignarnuevo/ver.blade.php ENDPATH**/ ?>