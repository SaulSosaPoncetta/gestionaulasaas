<?php
namespace Tests\Browser;

use App\Models\User;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Laravel\Dusk\Browser;
use Tests\DuskTestCase;

class LoginTest extends DuskTestCase
{
    public function test_el_usuario_puede_iniciar_sesion_correctamente(): void
    {
        // Crear un usuario de prueba en la base de datos
        $user = User::factory()->create([
            'email' => 'test@example.com',
        ]);

        $this->browse(function (Browser $browser) use ($user) {
            $browser->visit('/login')                   // 1. Visitar la ruta
                    ->type('email', $user->email)      // 2. Llenar el input por su atributo 'name'
                    ->type('password', 'password')
                    ->press('Iniciar Sesión')          // 3. Hacer clic en el botón con ese texto
                    ->assertPathIs('/dashboard')       // 4. Comprobar que redirigió a /dashboard
                    ->assertSee('Bienvenido');        // 5. Verificar que el texto está visible
        });
    }
}